<?php
session_start();
require '../../config.php';

$userId = $_SESSION['user_id'];

// Input form
$old = $_POST['old_password'] ?? '';
$new = $_POST['new_password'] ?? '';
$confirm = $_POST['confirm_password'] ?? '';

// Ambil password lama
$query = mysqli_query($conn, "SELECT password_hash FROM akun_user WHERE id='$userId'");
$user = mysqli_fetch_assoc($query);

// Validasi konfirmasi
if ($new !== $confirm) {
    $_SESSION['error'] = "Konfirmasi password tidak sama!";
    header("Location: index.php");
    exit;
}

// Validasi password lama
if (!password_verify($old, $user['password_hash'])) {
    $_SESSION['error'] = "Password lama salah!";
    header("Location: index.php");
    exit;
}

// Hash password baru
$newHash = password_hash($new, PASSWORD_DEFAULT);

// Update DB
mysqli_query($conn, "
    UPDATE akun_user 
    SET password_hash='$newHash', updated_at=NOW()
    WHERE id='$userId'
");

$_SESSION['success'] = "Password berhasil diperbarui!";
header("Location: index.php");
exit;

?>