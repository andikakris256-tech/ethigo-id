<?php
session_start();
require '../../config.php';

// Cek login
if(!isset($_SESSION['user_id'])){
    header("Location: ../../user&session/login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Ambil data user
$query = $conn->prepare("SELECT * FROM akun_user WHERE id = ?");
$query->bind_param("i", $user_id);
$query->execute();
$user = $query->get_result()->fetch_assoc();

// Jika user tidak ditemukan
if(!$user){
    die("User tidak ditemukan!");
}

// Update Profil
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $name        = trim($_POST['name']);
    $username    = trim($_POST['username']);
    $phone       = trim($_POST['phone']);
    $occupation  = trim($_POST['occupation']);
    $school      = trim($_POST['school']);
    $birth       = $_POST['birth'];
    $gender      = $_POST['gender'];

    $update = $conn->prepare("
        UPDATE akun_user 
        SET name=?, username=?, phone_number=?, occupation=?, school_origin=?, birth_date=?, gender=?, updated_at=NOW()
        WHERE id=?
    ");

    $update->bind_param("sssssssi", 
        $name, $username, $phone, $occupation, $school, $birth, $gender, $user_id
    );

    if($update->execute()){
        header("Location: index.php?success=1");
        exit;
    } else {
        $error = "Gagal memperbarui profil!";
    }
}

// Foto default jika kosong
$photo = $user['profile_photo'] 
    ? "../../uploads/profile/" . $user['profile_photo']
    : "https://placehold.co/150x150/46B5D1/151965?text=" . strtoupper(substr($user['name'],0,2));
?>

<!DOCTYPE html>
<html lang="id" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Saya | Ethigo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://unpkg.com/ionicons@5.5.2/dist/ionicons.js"></script>
    <style>
        /* Palet Warna Konsisten */
        :root {
            --bs-body-bg: #151965;
            --bs-body-color: #f0f0f0;
            --bs-border-color: #515585;
            --bs-tertiary-bg: #32407B; 
            --bs-secondary-bg: #32407B;
            --bs-primary: #46B5D1;
            --bs-primary-rgb: 70, 181, 209;
            --bs-nav-link-color: #b0c4de;
            --bs-nav-link-hover-color: #ffffff;
        }
        
        /* Styling Khusus Profil */
        .profile-header-card {
            background: linear-gradient(135deg, var(--bs-tertiary-bg) 0%, rgba(70, 181, 209, 0.2) 100%);
            border: 1px solid var(--bs-border-color);
        }
        .profile-avatar-lg {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            border: 4px solid var(--bs-primary);
            object-fit: cover;
            box-shadow: 0 0 20px rgba(70, 181, 209, 0.3);
        }
        .stat-card {
            transition: transform 0.2s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            border-color: var(--bs-primary);
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--bs-primary);
            box-shadow: 0 0 10px rgba(70, 181, 209, 0.3);
            background-color: var(--bs-secondary-bg);
            color: #fff;
        }
        /* Agar input readonly terlihat berbeda */
        .form-control:disabled, .form-control[readonly] {
            background-color: rgba(21, 25, 101, 0.5); /* Lebih gelap */
            opacity: 0.7;
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg bg-dark border-bottom sticky-top">
        <div class="container-fluid px-4">
            <a class="navbar-brand fw-bold fs-4" href="../dashboard/index.php">Ethigo<span class="text-primary">.</span></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mainNavbar">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 px-lg-3">
                    <li class="nav-item"><a class="nav-link" href="../dashboard/index.php">Dasbor</a></li>
                    <li class="nav-item"><a class="nav-link" href="../materi/index.php">Materi</a></li>
                    <li class="nav-item"><a class="nav-link" href="../perpustakaan/index.php">Perpustakaan</a></li>
                    <li class="nav-item"><a class="nav-link" href="../review/index.php">Review</a></li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle d-flex align-items-center active fw-bold" href="#" role="button" data-bs-toggle="dropdown">
                            <img src="<?= $user['profile_photo'] ? '../uploads/profile/'.$user['profile_photo'] : 'https://placehold.co/150x150/46B5D1/151965?text=User' ?> " class="rounded-circle me-2" style="object-fit: cover;" width="32" height="32"> <?= $_SESSION['username'] ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end bg-tertiary">
                            <li><a class="dropdown-item" href="../profile/index.php"><ion-icon name="person-circle-outline" class="me-2"></ion-icon> Profil Saya</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <form action="../../user&session/logout.php" method="post">
                                    <button name="logout" type="submit" class="dropdown-item text-danger"><ion-icon name="log-out-outline" class="me-2"></ion-icon> Logout</button>
                                </form>    
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Konten Utama -->
    <main class="container py-5">
        <?php if(isset($_GET['success'])): ?>
            <div class="alert alert-success">Profil berhasil diperbarui!</div>
        <?php endif; ?>

        <div class="row g-4">
            
            <!-- Kolom Kiri -->
            <div class="col-lg-4">
                <!-- Kartu Identitas -->
                <div class="card profile-header-card mb-4 text-center p-4">
                    <form id="formUploadFoto" action="upload_foto.php" method="post" enctype="multipart/form-data">
                        <div class="position-relative d-inline-block mx-auto mb-3">
                            
                            <!-- Foto Profil -->
                            <img src="<?= $user['profile_photo'] ? '../uploads/profile/'.$user['profile_photo'] : 'https://placehold.co/150x150/46B5D1/151965?text=User' ?>" 
                                alt="Foto Profil" 
                                class="profile-avatar-lg" 
                                id="previewProfile">

                            <!-- Tombol Kamera -->
                            <label for="fotoInput" 
                                class="btn btn-sm btn-primary position-absolute bottom-0 end-0 rounded-circle" 
                                title="Ganti Foto">
                                <ion-icon name="camera"></ion-icon>
                            </label>

                            <!-- Input File Hidden -->
                            <input type="file" name="profile_photo" id="fotoInput" class="d-none" accept="image/*">
                        </div>
                    </form>

                    <h3 class="fw-bold mb-1"><?= $user['name'] ?></h3>
                    <p class="text-primary mb-1">@<?= $user['username'] ?></p>
                    <span class="badge bg-primary text-dark px-3 py-2 rounded-pill"><?= $user['occupation'] ?: 'User' ?></span>
                </div>
            </div>

            <!-- Form Profil -->
            <div class="col-lg-8">
                <div class="card bg-tertiary border-secondary">
                    <div class="card-header border-secondary bg-transparent d-flex justify-content-between align-items-center py-3">
                        <h5 class="mb-0">Informasi Pribadi</h5>
                        <button class="btn btn-sm btn-primary" id="btnEdit">
                            <ion-icon name="create-outline" class="me-1"></ion-icon> Edit Profil
                        </button>
                    </div>

                    <div class="card-body p-4">
                        <form method="post">
                            <div class="row g-3">

                                <!-- Nama -->
                                <div class="col-md-6">
                                    <label class="form-label text-white-50">Nama Lengkap</label>
                                    <input type="text" 
                                           name="name"
                                           class="form-control bg-tertiary text-light border-secondary"
                                           value="<?= htmlspecialchars($user['name']) ?>" 
                                           disabled>
                                </div>

                                <!-- Username -->
                                <div class="col-md-6">
                                    <label class="form-label text-white-50">Username</label>
                                    <input type="text" 
                                           name="username"
                                           class="form-control bg-tertiary text-light border-secondary"
                                           value="<?= htmlspecialchars($user['username']) ?>" 
                                           disabled>
                                </div>

                                <!-- Email -->
                                <div class="col-md-6">
                                    <label class="form-label text-white-50">Email</label>
                                    <input type="email" 
                                           class="form-control bg-tertiary text-light border-secondary"
                                           value="<?= htmlspecialchars($user['email']) ?>" 
                                           readonly>
                                    <small class="text-white-50 fst-italic">*Email tidak dapat diubah</small>
                                </div>

                                <!-- Telepon -->
                                <div class="col-md-6">
                                    <label class="form-label text-white-50">Nomor Telepon</label>
                                    <input type="tel" 
                                           name="phone"
                                           class="form-control bg-tertiary text-light border-secondary"
                                           value="<?= htmlspecialchars($user['phone_number']) ?>" 
                                           disabled>
                                </div>

                                <!-- Pekerjaan -->
                                <div class="col-md-6">
                                    <label class="form-label text-white-50">Pekerjaan / Status</label>
                                    <input type="text" 
                                           name="occupation"
                                           class="form-control bg-tertiary text-light border-secondary"
                                           value="<?= htmlspecialchars($user['occupation']) ?>" 
                                           disabled>
                                </div>

                                <!-- Instansi -->
                                <div class="col-md-6">
                                    <label class="form-label text-white-50">Asal Sekolah / Instansi</label>
                                    <input type="text" 
                                           name="school"
                                           class="form-control bg-tertiary text-light border-secondary"
                                           value="<?= htmlspecialchars($user['school_origin']) ?>" 
                                           disabled>
                                </div>

                                <!-- Tanggal lahir -->
                                <div class="col-md-6">
                                    <label class="form-label text-white-50">Tanggal Lahir</label>
                                    <input type="date" 
                                           name="birth"
                                           class="form-control bg-tertiary text-light border-secondary"
                                           value="<?= $user['birth_date'] ?>" 
                                           disabled>
                                </div>

                                <!-- Gender -->
                                <div class="col-md-6">
                                    <label class="form-label text-white-50">Jenis Kelamin</label>
                                    <select name="gender" class="form-select bg-tertiary text-light border-secondary" disabled>
                                        <option <?= $user['gender']=='Laki-laki'?'selected':'' ?>>Laki-laki</option>
                                        <option <?= $user['gender']=='Perempuan'?'selected':'' ?>>Perempuan</option>
                                    </select>
                                </div>

                                <!-- Tombol -->
                                <div class="col-12 mt-4 d-none" id="actionButtons">
                                    <div class="d-flex gap-2 justify-content-end">
                                        <button type="button" class="btn btn-outline-light" id="btnCancel">Batal</button>
                                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                                    </div>
                                </div>

                            </div>
                        </form>
                    </div>
                </div>

                <!-- Bagian keamanan -->
                <div class="card bg-tertiary border-secondary mt-4">
                    <div class="card-header border-secondary bg-transparent py-3">
                        <h5 class="mb-0 text-danger">
                            <ion-icon name="shield-checkmark-outline" class="me-2"></ion-icon>Keamanan Akun
                        </h5>
                    </div>
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-light">Kata Sandi</h6>
                                <p class="text-white-50 small mb-0">Terakhir diubah <?= date("d M Y", strtotime($user['updated_at'])) ?></p>
                            </div>
                            <button class="btn btn-outline-light btn-sm" data-bs-toggle="modal" data-bs-target="#modalPassword">
                                Ubah Password
                            </button>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </main>

    <!-- Modal Ubah Password -->
    <div class="modal fade" id="modalPassword" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content bg-tertiary border-secondary text-light">
                
                <div class="modal-header border-secondary">
                    <h5 class="modal-title"><ion-icon name="lock-closed-outline" class="me-2"></ion-icon>Ubah Password</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>

                <form action="update_password.php" method="POST">
                <div class="modal-body">

                    <div class="mb-3">
                        <label class="form-label text-white-50">Password Lama</label>
                        <input type="password" class="form-control bg-tertiary text-light border-secondary" 
                            name="old_password" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label text-white-50">Password Baru</label>
                        <input type="password" class="form-control bg-tertiary text-light border-secondary" 
                            name="new_password" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label text-white-50">Konfirmasi Password Baru</label>
                        <input type="password" class="form-control bg-tertiary text-light border-secondary" 
                            name="confirm_password" required>
                    </div>

                </div>
                <div class="modal-footer border-secondary">
                    <button type="button" class="btn btn-outline-light" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
                </form>

            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Script edit mode -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const btnEdit = document.getElementById('btnEdit');
            const btnCancel = document.getElementById('btnCancel');
            const actionButtons = document.getElementById('actionButtons');
            const inputs = document.querySelectorAll('form input:not([readonly]), form select');

            btnEdit.addEventListener('click', () => {
                inputs.forEach(input => input.disabled = false);
                actionButtons.classList.remove('d-none');
                btnEdit.classList.add('d-none');
            });

            btnCancel.addEventListener('click', () => {
                inputs.forEach(input => input.disabled = true);
                actionButtons.classList.add('d-none');
                btnEdit.classList.remove('d-none');
            });
        });

        document.getElementById('fotoInput').addEventListener('change', function() {
            const file = this.files[0];
            if(file){
                const preview = document.getElementById('previewProfile');
                preview.src = URL.createObjectURL(file); // Preview instan
                document.getElementById('formUploadFoto').submit(); // Auto upload
            }
        });
    </script>
</body>
</html>