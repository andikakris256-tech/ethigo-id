<?php
session_start();
require '../../config.php';

$userId = $_SESSION['user_id'];

if (!empty($_FILES['profile_photo']['name'])) {

    $fileName = time() . '_' . basename($_FILES['profile_photo']['name']);
    $targetDir = "../uploads/profile/";
    $targetFile = $targetDir . $fileName;

    // Buat folder jika belum ada
    if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);

    // Validasi sederhana
    $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png', 'webp'];

    if (!in_array($fileType, $allowed)) {
        die("Format tidak didukung!");
    }

    if (move_uploaded_file($_FILES['profile_photo']['tmp_name'], $targetFile)) {

        // Hapus foto lama jika ada
        $qOld = mysqli_query($conn, "SELECT profile_photo FROM akun_user WHERE id='$userId'");
        $old = mysqli_fetch_assoc($qOld);

        if ($old['profile_photo'] && file_exists("../uploads/profile/".$old['profile_photo'])) {
            unlink("../uploads/profile/".$old['profile_photo']);
        }

        // Update DB
        mysqli_query($conn, "
            UPDATE akun_user 
            SET profile_photo='$fileName', updated_at=NOW() 
            WHERE id='$userId'
        ");
    }
}

header("Location: index.php");
exit;
