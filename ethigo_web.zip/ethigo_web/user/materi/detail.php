<?php
include '../../config.php';
session_start();

// Ambil slug dari URL
$slug = $_GET['slug'] ?? '';

// Cek apakah slug ada
if (!$slug) {
    header("Location: materi-user.php");
    exit;
}

// Query ambil data materi berdasarkan slug
$stmt = $conn->prepare("SELECT * FROM materi WHERE slug = ?");
$stmt->bind_param("s", $slug);
$stmt->execute();
$result = $stmt->get_result();
$materi = $result->fetch_assoc();

// Jika materi tidak ditemukan
if (!$materi) {
    header("Location: materi-user.php");
    exit;
}

?>
<!DOCTYPE html>
<html lang="id" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($materi['judul']) ?> | Ethigo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://unpkg.com/ionicons@5.5.2/dist/ionicons.js"></script>

    <style>
        :root {
            --bs-body-bg: #151965;
            --bs-body-color: #f0f0f0;
            --bs-border-color: #515585;
            --bs-tertiary-bg: #32407B; 
            --bs-secondary-bg: #32407B;
            --bs-primary: #46B5D1;
        }

        .detail-card {
            border: 1px solid var(--bs-border-color);
            background-color: var(--bs-tertiary-bg);
            border-radius: 12px;
            overflow: hidden;
        }

        .thumbnail-wrapper {
            width: 100%;
            height: 400px;
            overflow: hidden;
            border-bottom: 1px solid var(--bs-border-color);
        }

        .thumbnail-wrapper img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .description-text {
            font-size: 1.1rem;
            line-height: 1.8;
            color: #d1d5db;
        }

        @media (max-width: 768px) {
            .thumbnail-wrapper {
                height: 250px;
            }
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg bg-tertiary border-bottom sticky-top">
        <div class="container-fluid px-4">
            <a class="navbar-brand fw-bold fs-4" href="../../dashboard/index.php">Ethigo<span class="text-primary">.</span></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mainNavbar">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 px-lg-3">
                    <li class="nav-item"><a class="nav-link" href="../../dashboard/index.php">Dasbor</a></li>
                    <li class="nav-item"><a class="nav-link" href="./index.php">Materi</a></li>
                    <li class="nav-item"><a class="nav-link" href="../../perpustakaan/index.php">Perpustakaan</a></li>
                    <li class="nav-item"><a class="nav-link" href="../../review/index.php">Review</a></li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown">
                            <img src="https://placehold.co/100x100/46B5D1/151965?text=AK" class="rounded-circle me-2" width="32" height="32">
                            Andika
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end bg-tertiary">
                            <li><a class="dropdown-item text-light" href="profile-user.php">Profil Saya</a></li>
                            <li><a class="dropdown-item text-danger" href="#">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Konten -->
    <main class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-10">

                <a href="./index.php" class="btn btn-outline-light mb-4 px-4 rounded-pill">
                    <ion-icon name="arrow-back-outline" class="me-2"></ion-icon> Kembali ke Daftar Materi
                </a>

                <article class="detail-card shadow-lg">

                    <!-- Thumbnail -->
                    <div class="thumbnail-wrapper">
                        <img src="../../dashboardAdmin/materi/<?= htmlspecialchars($materi['thumbnail_url']) ?>" alt="Thumbnail">
                    </div>

                    <div class="card-body p-4 p-md-5">

                        <h1 class="display-5 fw-bold text-light mb-4">
                            <?= htmlspecialchars($materi['judul']) ?>
                        </h1>

                        <div class="d-flex align-items-center text-white-50 mb-5 border-bottom border-secondary pb-4 gap-4">
                            <span>
                                <ion-icon name="person-circle-outline" class="me-1"></ion-icon> 
                                <?= htmlspecialchars($materi['created_by']) ?>
                            </span>
                            <span>
                                <ion-icon name="calendar-outline" class="me-1"></ion-icon> 
                                <?= date("d M Y", strtotime($materi['created_at'])) ?>
                            </span>
                        </div>

                        <div class="description-section">
                            <h4 class="text-primary mb-3">Tentang Materi Ini</h4>
                            <div class="description-text">
                                <?= nl2br($materi['description']) ?>
                            </div>
                        </div>
                    </div>

                </article>

            </div>
        </div>
    </main>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
