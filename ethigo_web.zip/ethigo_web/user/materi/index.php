<?php
include '../../config.php';
session_start();

// Ambil input pencarian
$q = trim($_GET['q'] ?? '');
$search = "%$q%";

$user_id = (int) $_SESSION['user_id'];

// ambil data user (dipakai di navbar & preview)
$user_q = $conn->prepare("SELECT * FROM akun_user WHERE id = ?");
$user_q->bind_param("i", $user_id);
$user_q->execute();
$user_res = $user_q->get_result();
$user = $user_res->fetch_assoc();

// Query materi
if ($q) {
    $stmt = $conn->prepare("SELECT * FROM materi 
                            WHERE judul LIKE ? 
                            OR description LIKE ?
                            ORDER BY created_at DESC");
    $stmt->bind_param("ss", $search, $search);
    $stmt->execute();
    $materi = $stmt->get_result();
} else {
    $materi = $conn->query("SELECT * FROM materi ORDER BY created_at DESC");
}
?>
<!DOCTYPE html>
<html lang="id" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Materi | Ethigo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://unpkg.com/ionicons@5.5.2/dist/ionicons.js"></script>
    <style>
        :root {
            --bs-body-bg: #151965;
            --bs-body-color: #f0f0f0;
            --bs-border-color: #515585;
            --bs-tertiary-bg: #32407B; 
            --bs-secondary-bg: #32407B;
            --bs-primary: #46B5D1;
            --bs-primary-rgb: 70, 181, 209;
            --bs-nav-link-color: #b0c4de;
            --bs-nav-link-hover-color: #ffffff;
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--bs-primary);
            box-shadow: 0 0 15px 0 rgba(var(--bs-primary-rgb), 0.5);
        }
        .card { transition: transform 0.2s; }
        .card:hover { transform: translateY(-5px); border-color: var(--bs-primary); }
        .category-btn.active { background-color: var(--bs-primary); color: #000; border-color: var(--bs-primary); }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg bg-dark border-bottom sticky-top">
        <div class="container-fluid px-4">
            <a class="navbar-brand fw-bold fs-4" href="../dashboard/index.php">Ethigo<span class="text-primary">.</span></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mainNavbar">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 px-lg-3">
                    <li class="nav-item"><a class="nav-link" href="../dashboard/index.php">Beranda</a></li>
                    <li class="nav-item"><a class="nav-link active" href="./index.php">Materi</a></li>
                    <li class="nav-item"><a class="nav-link" href="../perpustakaan/index.php">Perpustakaan</a></li>
                    <li class="nav-item"><a class="nav-link" href="../review/index.php">Review</a></li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle d-flex align-items-center active fw-bold" href="#" role="button" data-bs-toggle="dropdown">
                        <?php
                            $profile_src = 'https://placehold.co/150x150/46B5D1/151965?text=User';
                            if (!empty($user['profile_photo'])) {
                                // sesuaikan path upload kalau foldermu beda, contoh ../uploads/profile/
                                $profile_src = htmlspecialchars('../uploads/profile/' . $user['profile_photo']);
                            }
                        ?>
                        <img src="<?= $profile_src ?>" class="rounded-circle me-2" style="object-fit: cover;" width="32" height="32">
                        <?= htmlspecialchars($_SESSION['username'] ?? $user['username'] ?? 'User') ?>
                    </a>
                        <ul class="dropdown-menu dropdown-menu-end bg-tertiary">
                            <li><a class="dropdown-item" href="../profile/index.php"><ion-icon name="person-circle-outline" class="me-2"></ion-icon> Profil Saya</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <form action="../../user&session/logout.php" method="post">
                                    <button name="logout" type="submit" class="dropdown-item text-danger"><ion-icon name="log-out-outline" class="me-2"></ion-icon> Logout</button>
                                </form>    
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Konten Utama -->
    <main class="container py-5">
        <div class="text-center mb-5">
            <h1 class="fw-bold">Katalog Materi</h1>
            <p class="text-white-50">Tingkatkan keahlianmu dengan materi terstruktur.</p>
        </div>

        <!-- Filter & Search -->
        <div class="row g-3 mb-5 justify-content-center">
            <div class="col-md-8">
                <form method="GET" class="input-group input-group-lg">
                    <span class="input-group-text bg-tertiary border-secondary text-white-50">
                        <ion-icon name="search"></ion-icon>
                    </span>
                    <input 
                        type="text" 
                        name="q" 
                        value="<?= htmlspecialchars($q) ?>"
                        class="form-control bg-tertiary border-secondary text-light"
                        placeholder="Cari materi apa hari ini?">
                    <button class="btn btn-primary">Cari</button>
                </form>
            </div>
        </div>

        <!-- Grid Materi -->
        <div class="row g-4">
            <?php if ($materi->num_rows > 0): ?>
                <?php while ($m = $materi->fetch_assoc()): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card bg-tertiary border-secondary h-100">
                            <img src="../../dashboardAdmin/materi/<?= $m['thumbnail_url'] ?>" class="card-img-top" alt="Thumbnail">
                            <div class="card-body d-flex flex-column">
                                <div class="badge bg-primary text-dark mb-2 w-25">Materi</div>
                                <h5 class="card-title"><?= $m['judul'] ?></h5>
                                <p class="card-text text-white-50 small"><?= $m['description'] ?></p>
                                <div class="mt-auto d-flex justify-content-between align-items-center">
                                    <small class="text-white-50"><ion-icon name="time-outline" class="me-1"></ion-icon> Belajar</small>
                                    <a href="detail.php?slug=<?= $m['slug'] ?>" class="btn btn-sm btn-primary">Mulai Belajar</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p class="text-center text-white-50">Tidak ada materi ditemukan.</p>
            <?php endif; ?>
        </div>

    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
