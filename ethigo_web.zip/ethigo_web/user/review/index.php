<?php
include '../../config.php';
session_start();

// pastikan login
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header("Location: ../../user&session/login.php");
    exit;
}

$user_id = (int) $_SESSION['user_id'];

// ambil data user (dipakai di navbar & preview)
$user_q = $conn->prepare("SELECT * FROM akun_user WHERE id = ?");
$user_q->bind_param("i", $user_id);
$user_q->execute();
$user_res = $user_q->get_result();
$user = $user_res->fetch_assoc();

// Ambil list materi (untuk modal bila perlu)
$materi_q = $conn->query("SELECT id, judul FROM materi ORDER BY created_at DESC");
$materi_list = $materi_q ? $materi_q->fetch_all(MYSQLI_ASSOC) : [];

// Ambil seluruh review (review umum). 
// NOTE: gunakan alias avatar_url supaya sesuai di view
$review_q = $conn->query("
    SELECT r.*, u.name, u.profile_photo AS avatar_url
    FROM review r
    LEFT JOIN akun_user u ON u.id = r.user_id
    WHERE r.status IN ('accepted','approved')
    ORDER BY r.created_at DESC
");
$reviews = $review_q ? $review_q->fetch_all(MYSQLI_ASSOC) : [];

// Hitung statistik rating (hanya accepted/approved)
$stat_q = $conn->query("SELECT COUNT(*) as total, AVG(rating) as avg_rating FROM review WHERE status IN ('accepted','approved')");
$stat = $stat_q ? $stat_q->fetch_assoc() : ['total' => 0, 'avg_rating' => 0];
$avg_rating = number_format($stat['avg_rating'] ?? 0, 1);
$total_reviews = $stat['total'] ?? 0;
?>
<!DOCTYPE html>
<html lang="id" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review | Ethigo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://unpkg.com/ionicons@5.5.2/dist/ionicons.js"></script>

    <style>
        :root {
            --bs-body-bg: #151965;
            --bs-body-color: #f0f0f0;
            --bs-border-color: #515585;
            --bs-tertiary-bg: #32407B; 
            --bs-primary: #46B5D1;
        }
        .star-rating ion-icon { color: #FFD700; font-size: 1.1rem; }
        .review-card { border-left: 4px solid var(--bs-primary); transition: .2s; }
        .review-card:hover { transform: translateX(5px); background: rgba(50,64,123,.8); }
        .review-badge {
            font-size: .8rem; background: rgba(70,181,209,.15); 
            color: var(--bs-primary); padding: .3rem .8rem;
            border-radius: 20px; border: 1px solid rgba(70,181,209,.3);
        }
    </style>
</head>
<body>

<!-- NAVBAR (TETAP SAMA) -->
<nav class="navbar navbar-expand-lg bg-dark border-bottom sticky-top">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold fs-4" href="../dashboard/index.php">Ethigo<span class="text-primary">.</span></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="mainNavbar">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 px-lg-3">
                <li class="nav-item"><a class="nav-link" href="../dashboard/index.php">Beranda</a></li>
                <li class="nav-item"><a class="nav-link" href="../materi/index.php">Materi</a></li>
                <li class="nav-item"><a class="nav-link" href="../perpustakaan/index.php">Perpustakaan</a></li>
                <li class="nav-item"><a class="nav-link active" href="./index.php">Review</a></li>
            </ul>

            <ul class="navbar-nav ms-auto">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle d-flex align-items-center active fw-bold" href="#" role="button" data-bs-toggle="dropdown">
                        <?php
                            $profile_src = 'https://placehold.co/150x150/46B5D1/151965?text=User';
                            if (!empty($user['profile_photo'])) {
                                // sesuaikan path upload kalau foldermu beda, contoh ../uploads/profile/
                                $profile_src = htmlspecialchars('../uploads/profile/' . $user['profile_photo']);
                            }
                        ?>
                        <img src="<?= $profile_src ?>" class="rounded-circle me-2" style="object-fit: cover;" width="32" height="32">
                        <?= htmlspecialchars($_SESSION['username'] ?? $user['username'] ?? 'User') ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end bg-tertiary">
                        <li><a class="dropdown-item" href="../profile/index.php">
                            <ion-icon name="person-circle-outline" class="me-2"></ion-icon> Profil Saya</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <form action="../../user&session/logout.php" method="post">
                                <button name="logout" type="submit" class="dropdown-item text-danger">
                                    <ion-icon name="log-out-outline" class="me-2"></ion-icon> Logout
                                </button>
                            </form>    
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- KONTEN -->
<main class="container py-5">
    <div class="row g-5">
        <!-- SIDEBAR -->
        <div class="col-lg-4">
            <div class="card bg-tertiary border-secondary mb-4 sticky-lg-top" style="top: 100px;">
                <div class="card-body text-center p-4">
                    <h5 class="text-white-50 mb-3">Rating Keseluruhan</h5>
                    <h3 class="fw-bold display-4"><?= htmlspecialchars($avg_rating) ?></h3>

                    <div class="star-rating mb-2">
                        <?php for($i=1;$i<=5;$i++): ?>
                            <ion-icon name="<?= ($i <= round($avg_rating)) ? 'star' : 'star-outline' ?>"></ion-icon>
                        <?php endfor; ?>
                    </div>

                    <p class="text-white-50 small">Berdasarkan <?= (int)$total_reviews ?> ulasan</p>

                    <hr class="border-secondary my-4">

                    <!-- Button -->
                    <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#reviewModal">
                        <ion-icon name="create-outline" class="me-1"></ion-icon> Tulis Review Baru
                    </button>
                </div>
            </div>
        </div>

        <!-- LIST REVIEW -->
        <div class="col-lg-8">
            <h4 class="mb-4">Ulasan Terbaru</h4>

            <?php if (count($reviews) > 0): ?>
                <?php foreach($reviews as $r): ?>
                <div class="card bg-tertiary border-secondary review-card mb-3">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <div class="d-flex align-items-center">
                                <?php
                                    $avatar = 'https://placehold.co/50x50/515585/E7F2EF?text=U';
                                    if (!empty($r['avatar_url'])) {
                                        $avatar = htmlspecialchars('../uploads/profile/' . $r['avatar_url']);
                                    }
                                ?>
                                <img src="<?= $avatar ?>" class="rounded-circle me-3" width="40" height="40" style="object-fit:cover;">
                                <div>
                                    <h6 class="mb-0 text-light"><?= htmlspecialchars($r['name'] ?? 'User') ?></h6>
                                    <small class="text-white-50"><?= date("d M Y", strtotime($r['created_at'])) ?></small>
                                </div>
                            </div>
                            <div class="star-rating">
                                <?php for($i=1;$i<=5;$i++): ?>
                                    <ion-icon name="<?= ($i <= (int)$r['rating']) ? 'star' : 'star-outline' ?>"></ion-icon>
                                <?php endfor; ?>
                            </div>
                        </div>

                        <p class="text-light"><?= nl2br(htmlspecialchars($r['comment'])) ?></p>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="alert alert-info text-center">Belum ada review.</div>
            <?php endif; ?>

        </div>
    </div>
</main>

<!-- MODAL TULIS REVIEW -->
<div class="modal fade" id="reviewModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form class="modal-content bg-tertiary border-secondary" method="post" action="review_add.php">
            <div class="modal-header border-secondary">
                <h1 class="modal-title fs-5 fw-bold text-light">Tulis Ulasan Baru</h1>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <div class="mb-3">
                    <label class="form-label text-white-50">Rating</label>
                    <select class="form-select bg-dark border-secondary text-light" name="rating" required>
                        <option value="5">⭐⭐⭐⭐⭐ (Sangat Bagus)</option>
                        <option value="4">⭐⭐⭐⭐ (Bagus)</option>
                        <option value="3">⭐⭐⭐ (Cukup)</option>
                        <option value="2">⭐⭐ (Kurang)</option>
                        <option value="1">⭐ (Sangat Kurang)</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label text-white-50">Komentar</label>
                    <textarea name="comment" class="form-control bg-dark border-secondary text-light" rows="4" required></textarea>
                </div>

            </div>

            <div class="modal-footer border-secondary">
                <button type="button" class="btn btn-outline-light" data-bs-dismiss="modal">Batal</button>
                <button type="submit" name="save" class="btn btn-primary">Kirim Review</button>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
