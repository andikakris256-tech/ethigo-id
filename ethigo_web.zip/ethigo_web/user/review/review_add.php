<?php
include '../../config.php';
session_start();

$user_id = $_SESSION['user_id'] ?? 0;
$rating = $_POST['rating'];
$comment = trim($_POST['comment']);

$conn->query("
    INSERT INTO review (user_id, rating, comment, status, created_at)
    VALUES ($user_id, '$rating', '$comment', 'pending', NOW())
");

header("Location: index.php");
exit;
