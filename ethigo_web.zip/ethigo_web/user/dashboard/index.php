<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] == '') {
    header("Location: ../../user&session/login.php");
    exit;
}

include '../../config.php';

$q = trim($_GET['q'] ?? '');

$user_id = (int) $_SESSION['user_id'];

// ambil data user (dipakai di navbar & preview)
$user_q = $conn->prepare("SELECT * FROM akun_user WHERE id = ?");
$user_q->bind_param("i", $user_id);
$user_q->execute();
$user_res = $user_q->get_result();
$user = $user_res->fetch_assoc();

if ($q != '') {
    // Search materi
    $materi = $conn->prepare("
        SELECT * FROM materi
        WHERE judul LIKE ? OR description LIKE ?
        ORDER BY id DESC
    ");
    $like = "%$q%";
    $materi->bind_param("ss", $like, $like);
    $materi->execute();
    $materi = $materi->get_result();

    // Search perpustakaan
    $perpus = $conn->prepare("
        SELECT * FROM perpustakaan
        WHERE judul LIKE ?
        ORDER BY id DESC
    ");
    $perpus->bind_param("s", $like);
    $perpus->execute();
    $perpus = $perpus->get_result();

    $isSearching = true;

} else {
    // Default tampilkan 6 materi & 10 buku terbaru
    $materi = $conn->query("SELECT * FROM materi ORDER BY id DESC LIMIT 6");
    $perpus = $conn->query("SELECT * FROM perpustakaan ORDER BY id DESC LIMIT 10");
    $isSearching = false;
}

// Ambil data materi
$materi = $conn->query("SELECT * FROM materi ORDER BY id DESC LIMIT 6");

// Ambil data perpustakaan
$perpus = $conn->query("SELECT * FROM perpustakaan ORDER BY id DESC LIMIT 10");
?>

<!DOCTYPE html>
<html lang="id" data-bs-theme="dark"> <!-- Mengatur tema dark Bootstrap -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dasbor Pengguna | Ethigo</title>
    
    <!-- 1. Bootstrap CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" xintegrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    
    <!-- 2. Ionicons (tetap kita pakai) -->
    <script src="https://unpkg.com/ionicons@5.5.2/dist/ionicons.js"></script>
    
    <link rel="stylesheet" href="../aset/style.css">
</head>
<body>

    <!-- 1. Navbar (Bootstrap) -->
    <nav class="navbar navbar-expand-lg bg-dark border-bottom sticky-top">
        <div class="container-fluid px-4">
            <!-- Logo -->
            <a class="navbar-brand fw-bold fs-4" href="#">Ethigo<span class="text-primary">.</span></a>
            
            <!-- Tombol Toggle (Mobile) -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar" aria-controls="mainNavbar" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <!-- Menu -->
            <div class="collapse navbar-collapse" id="mainNavbar">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 px-lg-3">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="./index.php">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../materi/index.php">Materi</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../perpustakaan/index.php">Perpustakaan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../review/index.php">Review</a>
                    </li>
                </ul>
                
                <!-- Profile Dropdown (di Kanan) -->
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle d-flex align-items-center active fw-bold" href="#" role="button" data-bs-toggle="dropdown">
                        <?php
                            $profile_src = 'https://placehold.co/150x150/46B5D1/151965?text=User';
                            if (!empty($user['profile_photo'])) {
                                // sesuaikan path upload kalau foldermu beda, contoh ../uploads/profile/
                                $profile_src = htmlspecialchars('../uploads/profile/' . $user['profile_photo']);
                            }
                        ?>
                        <img src="<?= $profile_src ?>" class="rounded-circle me-2" style="object-fit: cover;" width="32" height="32">
                        <?= htmlspecialchars($_SESSION['username'] ?? $user['username'] ?? 'User') ?>
                    </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="../profile/index.php"><ion-icon name="person-circle-outline" class="me-2"></ion-icon> Profil Saya</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <form action="../../user&session/logout.php" method="post">
                                    <button name="logout" type="submit" class="dropdown-item text-danger"><ion-icon name="log-out-outline" class="me-2"></ion-icon> Logout</button>
                                </form>    
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- 2. Konten Utama -->
    <main class="container-fluid p-4">
        
        <!-- 2.1 Hero Section (Tengah, Tanpa Gambar) -->
        <section class="bg-tertiary p-5 rounded-3 text-center mb-4">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <h1 class="display-5 fw-bold">Selamat Datang, <span><?= $_SESSION['username'] ?></span>!</h1>
                    <p class="fs-5 text-white-50 mb-4">Lanjutkan progres belajarmu hari ini dan jelajahi materi baru untuk menambah wawasanmu.</p>
                    
                    <!-- Search Bar (Bootstrap Input Group) -->
                    <form method="GET">
                        <div class="input-group input-group-lg mb-4 mx-auto" style="max-width: 600px;">
                            <span class="input-group-text bg-transparent border-primary text-primary">
                                <ion-icon name="search-outline"></ion-icon>
                            </span>
                            <input type="text" 
                                name="q"
                                class="form-control bg-transparent border-primary" 
                                placeholder="Cari materi atau buku..." 
                                style="color: white;"
                                value="<?= isset($_GET['q']) ? htmlspecialchars($_GET['q']) : '' ?>">
                        </div>
                    </form>
                </div>
            </div>
        </section>

        <!-- 2.2 Materi Saya (Bootstrap Grid & Cards) -->
        <section class="mb-4">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <h2 class="h4 mb-0">
                    <?= $isSearching ? 'Hasil Pencarian Materi' : 'Materi Kami' ?>
                </h2>
                <a href="../materi/index.php" class="btn btn-sm btn-outline-primary">Lihat Semua</a>
            </div>

            <div class="row g-4">
                <?php if ($materi->num_rows > 0): ?>
                    <?php while ($m = $materi->fetch_assoc()): ?>
                        <div class="col-md-6 col-lg-4">
                            <div class="card bg-tertiary border-secondary h-100">
                                
                                <img src="../../dashboardAdmin/materi/<?= $m['thumbnail_url'] ?>" class="card-img-top" alt="Thumbnail Materi">
        
                                <div class="card-body d-flex flex-column">
                                    <h5 class="card-title"><?= $m['judul'] ?></h5>
                                    <p class="card-text text-white-50 small">
                                        <?= mb_strimwidth($m['description'], 0, 70, "...") ?>
                                    </p>
        
                                    <div class="mt-auto">
                                        <a href="../materi/detail.php?slug=<?= $m['slug'] ?>" 
                                        class="btn btn-primary w-100 mt-2">
                                            Buka Materi
                                        </a>
                                    </div>
                                </div>
        
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p class="text-white-50">Tidak ada materi ditemukan.</p>
                <?php endif; ?>
            </div>
        </section>

        <!-- 2.3 Perpustakaan (Scroll Horizontal) -->
        <section class="mb-4">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <h2 class="h4 mb-0">
                    <?= $isSearching ? 'Hasil Pencarian Buku' : 'Perpustakaan Digital' ?>
                </h2>
                <a href="../perpustakaan/index.php" class="btn btn-sm btn-outline-primary">Lihat Semua</a>
            </div>

            <div class="buku-scroll-wrapper">
                <div class="d-flex gap-3">
                    
                    <?php while ($b = $perpus->fetch_assoc()): ?>
                        <a href="<?= $b['link'] ?>" target="_blank" class="buku-card text-center">
                            <img src="../../dashboardAdmin/perpustakaan/<?= $b['cover_url'] ?>" 
                                class="rounded-2 mb-2" 
                                alt="Cover Buku" 
                                style="width: 150px; height: 200px; object-fit: cover;">

                            <h6 class="fs-6 fw-normal mb-0 text-white">
                                <?= $b['judul'] ?>
                            </h6>
                        </a>
                    <?php endwhile; ?>

                </div>
            </div>
        </section>
    </main>

    <!-- 3. Bootstrap JS Bundle CDN (diperlukan untuk dropdown) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" xintegrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>