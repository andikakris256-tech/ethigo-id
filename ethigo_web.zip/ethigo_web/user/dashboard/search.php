<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../user&session/login.php");
    exit;
}

include '../../config.php';

// Ambil query pencarian
$q = trim($_GET['q'] ?? '');

// Query search materi
$sqlMateri = $conn->prepare("
    SELECT * FROM materi
    WHERE judul LIKE ? OR description LIKE ?
");
$like = "%$q%";
$sqlMateri->bind_param("ss", $like, $like);
$sqlMateri->execute();
$materi = $sqlMateri->get_result();

// Query search perpustakaan
$sqlPerpus = $conn->prepare("
    SELECT * FROM perpustakaan
    WHERE judul LIKE ?
");
$sqlPerpus->bind_param("s", $like);
$sqlPerpus->execute();
$perpus = $sqlPerpus->get_result();
?>
