<?php
include '../../config.php';
session_start();

// Ambil kata pencarian (jika ada)
$search = $_GET['q'] ?? "";

$user_id = (int) $_SESSION['user_id'];

// ambil data user (dipakai di navbar & preview)
$user_q = $conn->prepare("SELECT * FROM akun_user WHERE id = ?");
$user_q->bind_param("i", $user_id);
$user_q->execute();
$user_res = $user_q->get_result();
$user = $user_res->fetch_assoc();

// Query dynamic
if ($search) {
    $stmt = $conn->prepare("SELECT * FROM perpustakaan WHERE judul LIKE ?");
    $param = "%".$search."%";
    $stmt->bind_param("s", $param);
} else {
    $stmt = $conn->prepare("SELECT * FROM perpustakaan ORDER BY created_at DESC");
}

$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="id" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perpustakaan | Ethigo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://unpkg.com/ionicons@5.5.2/dist/ionicons.js"></script>
    <style>
        :root {
            --bs-body-bg: #151965;
            --bs-body-color: #f0f0f0;
            --bs-border-color: #515585;
            --bs-tertiary-bg: #32407B; 
            --bs-primary: #46B5D1;
            --bs-primary-rgb: 70, 181, 209;
            --bs-nav-link-color: #b0c4de;
            --bs-nav-link-hover-color: #ffffff;
        }
        .book-card { transition: transform 0.3s ease; }
        .book-card:hover { transform: translateY(-8px); }
        .book-cover { 
            height: 280px; 
            object-fit: cover; 
            border-radius: 8px; 
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
        }
        .book-card:hover .book-cover { 
            box-shadow: 0 8px 25px rgba(70, 181, 209, 0.4); 
            border: 2px solid var(--bs-primary); 
        }
    </style>
</head>
<body>

    <!-- Navbar (tidak disentuh) -->
    <nav class="navbar navbar-expand-lg bg-dark border-bottom sticky-top">
        <div class="container-fluid px-4">
            <a class="navbar-brand fw-bold fs-4" href="../dashboard/index.php">Ethigo<span class="text-primary">.</span></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mainNavbar">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 px-lg-3">
                    <li class="nav-item"><a class="nav-link" href="../dashboard/index.php">Beranda</a></li>
                    <li class="nav-item"><a class="nav-link" href="../materi/index.php">Materi</a></li>
                    <li class="nav-item"><a class="nav-link active" href="./index.php">Perpustakaan</a></li>
                    <li class="nav-item"><a class="nav-link" href="../review/index.php">Review</a></li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle d-flex align-items-center active fw-bold" href="#" role="button" data-bs-toggle="dropdown">
                        <?php
                            $profile_src = 'https://placehold.co/150x150/46B5D1/151965?text=User';
                            if (!empty($user['profile_photo'])) {
                                // sesuaikan path upload kalau foldermu beda, contoh ../uploads/profile/
                                $profile_src = htmlspecialchars('../uploads/profile/' . $user['profile_photo']);
                            }
                        ?>
                        <img src="<?= $profile_src ?>" class="rounded-circle me-2" style="object-fit: cover;" width="32" height="32">
                        <?= htmlspecialchars($_SESSION['username'] ?? $user['username'] ?? 'User') ?>
                    </a>
                        <ul class="dropdown-menu dropdown-menu-end bg-tertiary">
                            <li><a class="dropdown-item" href="../profile/index.php"><ion-icon name="person-circle-outline" class="me-2"></ion-icon> Profil Saya</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <form action="../../user&session/logout.php" method="post">
                                    <button name="logout" type="submit" class="dropdown-item text-danger">
                                        <ion-icon name="log-out-outline" class="me-2"></ion-icon> Logout
                                    </button>
                                </form>    
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>


    <!-- Konten -->
    <main class="container py-5">

        <!-- Header + Search -->
        <div class="d-flex justify-content-between align-items-center mb-5 flex-wrap gap-3">
            <div>
                <h1 class="fw-bold mb-0">Perpustakaan Digital</h1>
                <p class="text-white-50">Sumber daya bacaan untuk mendukung pembelajaranmu.</p>
            </div>

            <form method="GET" class="input-group" style="max-width: 300px;">
                <input 
                    type="text" 
                    name="q" 
                    value="<?= htmlspecialchars($search) ?>" 
                    class="form-control bg-tertiary border-secondary text-light"
                    placeholder="Cari judul buku..."
                >
                <button class="btn btn-primary">
                    <ion-icon name="search"></ion-icon>
                </button>
            </form>
        </div>


        <!-- Grid Buku -->
        <div class="row row-cols-2 row-cols-md-4 row-cols-lg-5 g-4">

            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="col">
                        <div class="book-card text-center h-100">
                            <a href="<?= htmlspecialchars($row['link']) ?>" target="_blank" class="text-decoration-none">
                                
                                <!-- Cover -->
                                <img 
                                    src="../../dashboardAdmin/perpustakaan/<?= htmlspecialchars($row['cover_url']) ?>" 
                                    class="book-cover w-100 mb-3" 
                                    alt="<?= htmlspecialchars($row['judul']) ?>"
                                >

                                <!-- Judul -->
                                <h6 class="text-light mb-1">
                                    <?= htmlspecialchars($row['judul']) ?>
                                </h6>

                                <small class="text-primary">
                                    Baca Sekarang <ion-icon name="arrow-forward"></ion-icon>
                                </small>
                            </a>
                        </div>
                    </div>
                <?php endwhile; ?>
            
            <?php else: ?>
                <div class="col-12 text-center py-5">
                    <h5 class="text-light">Tidak ada buku ditemukan.</h5>
                </div>
            <?php endif; ?>

        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
