<?php

session_start();

if (!$_SESSION['user_id']) {
    header("Location: ./user&session/login.php");
}

?>