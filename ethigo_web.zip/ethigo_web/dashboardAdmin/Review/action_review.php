<?php
include '../../config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: index.php");
    exit;
}

$action = $_POST['action'] ?? '';
$id = $_POST['review_id'] ?? 0;

if (!$id) {
    header("Location: index.php?error=invalid-id");
    exit;
}

if ($action === 'approve') {
    $conn->query("UPDATE review SET status='approved' WHERE id=$id");
    header("Location: index.php?success=approved");
    exit;
}

if ($action === 'delete') {
    $conn->query("DELETE FROM review WHERE id=$id");
    header("Location: index.php?success=deleted");
    exit;
}

header("Location: index.php");
