<?php

include '../../config.php';
session_start();

// ----------------------------
// 1. QUERY AMBIL SEMUA REVIEW
// ----------------------------
$reviews = $conn->query("
    SELECT review.*, akun_user.name, akun_user.email 
    FROM review
    LEFT JOIN akun_user ON akun_user.id = review.user_id
    ORDER BY review.created_at DESC
");

// ----------------------------
// 2. STATISTIK REVIEW
// ----------------------------
$stats = [];

// total review
$stats['total'] = $conn->query("SELECT COUNT(*) AS jml FROM review")->fetch_assoc()['jml'];

// pending
$stats['pending'] = $conn->query("SELECT COUNT(*) AS jml FROM review WHERE status='pending'")->fetch_assoc()['jml'];

// approved
$stats['approved'] = $conn->query("SELECT COUNT(*) AS jml FROM review WHERE status='approved'")->fetch_assoc()['jml'];

// rata-rata rating
$avg = $conn->query("SELECT AVG(rating) AS avg_rating FROM review")->fetch_assoc()['avg_rating'];
$stats['average'] = $avg ? number_format($avg, 1) : 0;

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Review - Ethigo</title>
    
    <!-- Memuat Font Inter dari Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../style.css">

    <!-- Memuat Ionicons (Bundel Lengkap) -->
    <script src="https://unpkg.com/ionicons@5.5.2/dist/ionicons.js"></script>
    
    <!-- MEMUAT CHART.JS (Untuk Grafik) -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

</head>
<body>

    <div class="dashboard-container">
        
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header"><h1>Ethigo<span>.</span></h1></div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="../Dashboard/index.php"><ion-icon name="grid-outline"></ion-icon><span>Dasbor</span></a></li>
                    <li><a href="../Materi/index.php"><ion-icon name="book-outline"></ion-icon><span>Materi</span></a></li>
                    <li><a href="../Pengguna/index.php"><ion-icon name="people-outline"></ion-icon><span>Pengguna</span></a></li>
                    <li><a href="../Perpustakaan/index.php"><ion-icon name="library-outline"></ion-icon><span>Perpustakaan</span></a></li>
                    <li><a href="#" class="active"><ion-icon name="star-outline"></ion-icon><span>Review</span></a></li>
                </ul>
            </nav>
             <div class="sidebar-footer">
                <nav class="sidebar-nav">
                    <ul>
                       <li><a href="../../user&session/login.php" id="logout-btn" class="logout-link"><ion-icon name="log-out-outline"></ion-icon><span>Logout</span></a></li>
                    </ul>
                </nav>
            </div>
        </aside>

        <!-- Main Content Area -->
        <div class="main-content">
            
            <!-- Header -->
            <header class="main-header">
                <div class="search-bar">
                    <ion-icon name="search-outline"></ion-icon>
                    <input type="text" placeholder="Cari review...">
                </div>
                <div class="header-profile">
                    <!-- ... (Icon dan profile sama seperti sebelumnya) ... -->
                    <div class="profile-info">
                        <img src="https://placehold.co/40x40/E7F2EF/19183B?text=AK" alt="Foto Profil">
                    </div>
                </div>
            </header>

            <!-- Content -->
            <main class="content-area">
                <h2 class="content-title">Manajemen Review</h2>
                
                <!-- Grid Atas: Grafik & Ringkasan -->
                <div class="top-grid">
                    <!-- Grafik (FITUR 2) -->
                    <div class="chart-container">
                        <canvas id="ratingChart"></canvas>
                    </div>
                    
                    <!-- Ringkasan Stats -->
                    <div class="stats-container">
                        <div class="stat-card stat-average">
                            <div class="stat-title">Rata-rata Rating</div>
                            <div class="stat-value">
                                <ion-icon name="star" class="stat-icon"></ion-icon><?= $stats['average'] ?>
                            </div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-title">Total Review</div>
                            <div class="stat-value"><?= $stats['total'] ?></div>
                        </div>

                        <div class="stat-card stat-pending">
                            <div class="stat-title">Menunggu Persetujuan</div>
                            <div class="stat-value"><?= $stats['pending'] ?></div>
                        </div>
                    </div>
                </div>

                <!-- Header Konten: Filter -->
                <div class="content-header">
                    <h3 style="font-size: 1.5rem; font-weight: 600;">Daftar Review</h3>
                    <div class="filter-group">
                        <button class="btn active" data-filter="all">Semua</button>
                        <button class="btn" data-filter="pending">Pending</button>
                        <button class="btn" data-filter="approved">Approved</button>
                    </div>
                </div>
                
                <!-- Tabel Data Review (dari tabel 'review') -->
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Pengguna</th> <!-- 'user_id' -->
                                <th>Rating</th> <!-- 'rating' (FITUR 1) -->
                                <th>Komentar</th> <!-- 'comment' -->
                                <th class="col-date">Tanggal</th> <!-- 'created_at' -->
                                <th>Status</th> <!-- 'status' -->
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $reviews->fetch_assoc()): ?>
                                <tr data-status="<?= $row['status'] ?>">
                                    
                                    <td>
                                        <div class="user-info">
                                            <img src="https://placehold.co/40x40/E7F2EF/19183B?text=<?= strtoupper(substr($row['name'],0,2)) ?>" alt="Foto">
                                            <div>
                                                <div class="user-name"><?= $row['name'] ?></div>
                                                <div class="user-email"><?= $row['email'] ?></div>
                                            </div>
                                        </div>
                                    </td>

                                    <td>
                                        <div class="rating-stars">
                                            <?php for ($i=1; $i<=5; $i++): ?>
                                                <?php if ($i <= $row['rating']): ?>
                                                    <ion-icon name="star"></ion-icon>
                                                <?php else: ?>
                                                    <ion-icon name="star-outline" class="star-outline"></ion-icon>
                                                <?php endif; ?>
                                            <?php endfor; ?>
                                        </div>
                                    </td>

                                    <td class="comment-cell"><?= $row['comment'] ?></td>

                                    <td class="col-date">
                                        <?= date("d M Y", strtotime($row['created_at'])) ?>
                                    </td>

                                    <td>
                                        <span class="status-badge status-<?= $row['status'] ?>">
                                            <?= $row['status'] ?>
                                        </span>
                                    </td>

                                    <td class="actions-cell">
                                        <?php if ($row['status'] == 'pending'): ?>
                                            <button class="btn-icon btn-approve" 
                                                    data-id="<?= $row['id'] ?>" 
                                                    data-name="<?= $row['name'] ?>">
                                                <ion-icon name="checkmark-circle-outline"></ion-icon>
                                            </button>
                                        <?php endif; ?>

                                        <button class="btn-icon btn-delete"
                                            data-id="<?= $row['id'] ?>"
                                            data-name="<?= $row['name'] ?>">
                                        <ion-icon name="trash-outline"></ion-icon>
                                    </button>
                                    </td>

                                </tr>
                            <?php endwhile; ?>
                        </tbody>

                    </table>
                </div>

            </main>
        </div>
    </div>

    <!-- Modal Konfirmasi Review -->
    <div class="modal" id="reviewConfirmModal">
        <div class="modal-content modal-confirm">
            <div class="modal-header">
                <h3 class="modal-title" id="reviewModalTitle">Konfirmasi</h3>
                <button class="modal-close" id="closeReviewModalBtn">
                    <ion-icon name="close-outline"></ion-icon>
                </button>
            </div>

            <div class="modal-body modal-body-confirm">
                <p id="reviewModalText">Yakin?</p>
            </div>

            <div class="modal-footer">
                <button class="btn btn-secondary" id="cancelReviewBtn">Batal</button>

                <form id="reviewForm" method="POST">
                    <input type="hidden" name="review_id" id="reviewItemId">
                    <input type="hidden" name="action" id="reviewAction">
                    <button type="submit" id="reviewSubmitBtn" class="btn btn-danger">Lanjutkan</button>
                </form>
            </div>
        </div>
    </div>

    <!-- JavaScript untuk Interaktivitas -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            
            // --- 1. Logika Grafik (FITUR 2) ---
            const ctx = document.getElementById('ratingChart').getContext('2d');
            const ratingChart = new Chart(ctx, {
                type: 'line', // Sesuai permintaan: grafik garis
                data: {
                    labels: ['1 Bintang', '2 Bintang', '3 Bintang', '4 Bintang', '5 Bintang'],
                    datasets: [{
                        label: 'Jumlah Review',
                        data: [3, 5, 12, 30, 50], // Data contoh
                        backgroundColor: 'rgba(161, 194, 189, 0.2)', // Area fill: --ethigo-mint
                        borderColor: 'rgba(161, 194, 189, 1)', // Garis: --ethigo-mint
                        pointBackgroundColor: 'rgba(161, 194, 189, 1)',
                        pointBorderColor: '#fff',
                        tension: 0.3, // Membuat garis sedikit melengkung
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            backgroundColor: 'rgba(25, 24, 59, 0.9)', // --ethigo-dark
                            titleColor: '#E7F2EF', // --ethigo-light
                            bodyColor: '#E7F2EF',
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: { color: 'rgba(112, 137, 147, 0.7)' }, // --ethigo-grayblue
                            grid: { color: 'rgba(112, 137, 147, 0.1)' } // --border-color
                        },
                        x: {
                            ticks: { color: 'rgba(112, 137, 147, 0.7)' }, // --ethigo-grayblue
                            grid: { color: 'rgba(112, 137, 147, 0.1)' } // --border-color
                        }
                    }
                }
            });

            const reviewConfirmModal = document.getElementById('reviewConfirmModal');
            const closeReviewModalBtn = document.getElementById('closeReviewModalBtn');
            const cancelReviewBtn = document.getElementById('cancelReviewBtn');
            const reviewModalTitle = document.getElementById('reviewModalTitle');
            const reviewModalText = document.getElementById('reviewModalText');
            const reviewSubmitBtn = document.getElementById('reviewSubmitBtn');
            const reviewItemId = document.getElementById('reviewItemId');
            const reviewAction = document.getElementById('reviewAction');
            const reviewForm = document.getElementById('reviewForm');

            function closeReviewModal() {
                reviewConfirmModal.style.display = "none";
            }

            closeReviewModalBtn.addEventListener('click', closeReviewModal);
            cancelReviewBtn.addEventListener('click', closeReviewModal);

            document.addEventListener('click', function(e) {
                const btn = e.target.closest('button');
                if (!btn) return;

                // --- APPROVE ---
                if (btn.classList.contains('btn-approve')) {
                    const id = btn.dataset.id;
                    const name = btn.dataset.name;

                    reviewModalTitle.textContent = "Terima Review";
                    reviewModalText.innerHTML = `Terima review dari <strong>${name}</strong>?`;

                    reviewSubmitBtn.className = "btn btn-success";
                    reviewSubmitBtn.textContent = "Ya, Terima";

                    reviewAction.value = "approve";
                    reviewItemId.value = id;

                    reviewForm.action = "action_review.php";
                    reviewConfirmModal.style.display = "flex";
                }

                // --- DELETE ---
                if (btn.classList.contains('btn-delete')) {
                    const id = btn.dataset.id;
                    const name = btn.dataset.name;

                    reviewModalTitle.textContent = "Hapus Review";
                    reviewModalText.innerHTML = `Hapus review dari <strong>${name}</strong>?`;

                    reviewSubmitBtn.className = "btn btn-danger";
                    reviewSubmitBtn.textContent = "Ya, Hapus";

                    reviewAction.value = "delete";
                    reviewItemId.value = id;

                    reviewForm.action = "action_review.php";
                    reviewConfirmModal.style.display = "flex";
                }
            });
            
            // --- 3. Logika Filter ---
            const filterButtons = document.querySelectorAll('.filter-group .btn');
            const tableRows = document.querySelectorAll('.data-table tbody tr');

            filterButtons.forEach(button => {
                button.addEventListener('click', () => {

                    // highlight btn aktif
                    filterButtons.forEach(btn => btn.classList.remove('active'));
                    button.classList.add('active');

                    const filter = button.dataset.filter; // all / pending / approved

                    tableRows.forEach(row => {
                        const status = row.getAttribute('data-status'); // ambil langsung dari <tr data-status="pending">

                        if (filter === "all" || status === filter) {
                            row.style.display = "";
                        } else {
                            row.style.display = "none";
                        }
                    });

                });
            });
        });
    </script>

</body>
</html>