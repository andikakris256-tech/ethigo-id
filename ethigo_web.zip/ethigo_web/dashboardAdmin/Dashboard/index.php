<?php

session_start();
if(empty($_SESSION['user_id'])){
    header('Location: login.php'); exit;
}
require '../../config.php';

// === TOTAL PENGGUNA (selain admin) & PERSENTASE ===
$stmt = $conn->prepare("
    SELECT
        SUM(CASE WHEN MONTH(created_at) = MONTH(CURRENT_DATE())
                 AND YEAR(created_at) = YEAR(CURRENT_DATE())
             THEN 1 ELSE 0 END) AS bulan_ini,
        SUM(CASE WHEN MONTH(created_at) = MONTH(DATE_SUB(CURRENT_DATE(), INTERVAL 1 MONTH))
                 AND YEAR(created_at) = YEAR(DATE_SUB(CURRENT_DATE(), INTERVAL 1 MONTH))
             THEN 1 ELSE 0 END) AS bulan_lalu
    FROM akun_user
    WHERE role != 'admin'
");
$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_assoc();
$stmt->close();

$bulan_ini  = (int)$row['bulan_ini'];
$bulan_lalu = (int)$row['bulan_lalu'];
$growth_user = ($bulan_lalu > 0) ? (($bulan_ini - $bulan_lalu) / $bulan_lalu) * 100 : ($bulan_ini > 0 ? 100 : 0);

// total user keseluruhan
$stmt = $conn->prepare("SELECT COUNT(*) AS total_pengguna FROM akun_user WHERE role != 'admin'");
$stmt->execute();
$res = $stmt->get_result();
$user = $res->fetch_assoc();
$stmt->close();


// === TOTAL MATERI & JUMLAH MINGGU INI ===
$stmt = $conn->prepare("
    SELECT
        COUNT(*) AS total_materi,
        SUM(CASE WHEN YEARWEEK(created_at, 1) = YEARWEEK(CURDATE(), 1)
             THEN 1 ELSE 0 END) AS materi_minggu_ini
    FROM materi
");
$stmt->execute();
$res = $stmt->get_result();
$materi = $res->fetch_assoc();
$stmt->close();


// === TOTAL DONASI TERKUMPUL ===
$stmt = $conn->prepare("
    SELECT COALESCE(SUM(amount), 0) AS total_donasi
    FROM donasi
");
$stmt->execute();
$res = $stmt->get_result();
$donasi = $res->fetch_assoc();
$stmt->close();


// === TOTAL REVIEW ===
$stmt = $conn->prepare("SELECT COUNT(*) AS total_review FROM review");
$stmt->execute();
$res = $stmt->get_result();
$review = $res->fetch_assoc();
$stmt->close();


// === DAFTAR MATERI (tanpa "dilihat") ===
$stmt = $conn->prepare("
    SELECT judul
    FROM materi
    ORDER BY created_at DESC
    LIMIT 5
");
$stmt->execute();
$res = $stmt->get_result();
$materi_list = $res->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$stmt = $conn->prepare("
    SELECT judul
    FROM perpustakaan
    ORDER BY created_at DESC
    LIMIT 5
");
$stmt->execute();
$res = $stmt->get_result();
$buku_list = $res->fetch_all(MYSQLI_ASSOC);
$stmt->close();

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dasbor Admin - Ethigo</title>
    
    <!-- Memuat Font Inter dari Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../style.css">

    <!-- Memuat Heroicons untuk ikon -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    
</head>
<body>

    <div class="dashboard-container">
        
        <!-- Sidebar -->
        <aside class="sidebar">
            <!-- Logo/Brand -->
            <div class="sidebar-header">
                <h1>Ethigo<span>.</span></h1>
            </div>
            
            <!-- Navigation -->
            <nav class="sidebar-nav">
                <ul>
                    <li>
                        <a href="#" class="active">
                            <ion-icon name="grid-outline"></ion-icon>
                            <span>Dasbor</span>
                        </a>
                    </li>
                    <li>
                        <a href="../Materi/index.php">
                            <ion-icon name="book-outline"></ion-icon>
                            <span>Materi</span>
                        </a>
                    </li>
                    <li>
                        <a href="../Pengguna/index.php">
                            <ion-icon name="people-outline"></ion-icon>
                            <span>Pengguna</span>
                        </a>
                    </li>
                    <li>
                        <a href="../Perpustakaan/index.php">
                            <ion-icon name="library-outline"></ion-icon>
                            <span>Perpustakaan</span>
                        </a>
                    </li>
                    <li>
                        <a href="../Review/index.php">
                            <ion-icon name="star-outline"></ion-icon>
                            <span>Review</span>
                        </a>
                    </li>
                </ul>
            </nav>
            
            <!-- Sidebar Footer -->
           <div class="sidebar-footer">
                <nav class="sidebar-nav">
                    <ul>
                       <li>
                        <form action="../../user&session/logout.php" method="post">
                            <button name="logout" type="submit"><ion-icon name="log-out-outline"></ion-icon> Logout</button>
                        </form>
                    </li>
                    </ul>
                </nav>
            </div>
        </aside>

        <!-- Main Content Area -->
        <div class="main-content">
            
            <!-- Header -->
            <header class="main-header">
                <!-- Search Bar -->
                <div class="search-bar">
                    <ion-icon name="search-outline"></ion-icon>
                    <input type="text" placeholder="Cari materi, pengguna, atau review...">
                </div>
                
                <!-- Header Icons & Profile -->
                <div class="header-profile">
                    <div class="header-icons">
                        <ion-icon name="notifications-outline"></ion-icon>
                        <ion-icon name="chatbubble-ellipses-outline"></ion-icon>
                    </div>
                    
                    <!-- Profile Dropdown -->
                    <div class="profile-info">
                        <img src="https://placehold.co/40x40/E7F2EF/19183B?text=AK" alt="Foto Profil">
                        <div class="profile-text">
                            <!-- Data dari tabel akun_user -->
                            <div class="profile-name"><?= $_SESSION['username'] ?></div>
                            <div class="profile-role">Admin</div>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Content -->
            <main class="content-area">
                <!-- Page Title -->
                <h2 class="content-title">Selamat Datang, <?= $_SESSION['username'] ?>!</h2>
                
                <!-- Grid untuk Widgets/Cards -->
                <div class="widget-grid">
                    
                    <!-- Card: Total Pengguna (akun_user) -->
                    <div class="widget-card">
                        <div class="widget-header">
                            <span class="widget-title">Total Pengguna</span>
                            <ion-icon name="people-outline"></ion-icon>
                        </div>
                        <div class="widget-value"><?= $user['total_pengguna'] ?></div>
                        <div class="widget-detail">
                            <?= ($growth_user >= 0 ? '+' : '') . number_format($growth_user, 1) ?>% dari bulan lalu
                        </div>
                    </div>
                    
                    <!-- Card: Total Materi -->
                    <div class="widget-card">
                        <div class="widget-header">
                            <span class="widget-title">Total Materi</span>
                            <ion-icon name="book-outline"></ion-icon>
                        </div>
                        <div class="widget-value"><?= $materi['total_materi'] ?></div>
                        <div class="widget-detail"><?= $materi['materi_minggu_ini'] ?> materi baru minggu ini</div>
                    </div>

                    <!-- Card: Total Donasi -->
                    <div class="widget-card">
                        <div class="widget-header">
                            <span class="widget-title">Donasi Terkumpul</span>
                            <ion-icon name="cash-outline"></ion-icon>
                        </div>
                        <div class="widget-value">Rp <?= number_format($donasi['total_donasi'], 0, ',', '.') ?></div>
                        <div class="widget-detail">Status: Success</div>
                    </div>

                    <!-- Card: Total Review -->
                    <div class="widget-card">
                        <div class="widget-header">
                            <span class="widget-title">Total Review</span>
                            <ion-icon name="star-outline"></ion-icon>
                        </div>
                        <div class="widget-value"><?= $review['total_review'] ?></div>
                        <div class="widget-detail">Review Pengguna</div>
                    </div>

                    <!-- Card: Daftar Materi -->
                    <div class="widget-card span-2">
                        <div class="widget-header">
                            <h3 class="widget-title">Daftar Materi</h3>
                        </div>
                        <div class="widget-list">
                            <?php foreach ($materi_list as $m): ?>
                                <div class="widget-list-item">
                                    <span class="item-title"><?= htmlspecialchars($m['judul']) ?></span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <!-- Card: Link Perpustakaan (perpustakaan) -->
                    <div class="widget-card">
                        <div class="widget-header">
                            <h3 class="widget-title">Perpustakaan</h3>
                        </div>
                        <div class="widget-list">
                             <?php foreach ($buku_list as $b): ?>
                                 <div class="widget-list-item">
                                     <span class="item-title"><?= htmlspecialchars($b['judul']) ?></span>
                                 </div>
                             <?php endforeach; ?>
                        </div>
                    </div>

                </div> <!-- End Widget Grid -->
            </main> <!-- End Content Area -->
        </div> <!-- End Main Content -->
    </div> <!-- End Dashboard Container -->

</body>
</html>