<?php
include '../../config.php';
session_start();

$action = $_POST['action'] ?? $_GET['action'] ?? '';

if ($action === 'toggleStatus') {
    $id = $_GET['id'] ?? 0;
    $status = $_GET['status'] ?? '';

    // Validasi
    if (!$id || !in_array($status, ['active', 'banned'])) {
        echo "invalid";
        exit;
    }

    // Prepared Statement
    $stmt = $conn->prepare("UPDATE akun_user SET status = ?, updated_at = NOW() WHERE id = ?");
    $stmt->bind_param("si", $status, $id);

    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "error";
    }
    
    $stmt->close();
    exit;
}
?>
