<?php
include '../../config.php';
include './crud_pengguna.php';
$result = $conn->query("SELECT * FROM akun_user WHERE role != 'admin' ORDER BY id DESC");

 ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Pengguna - Ethigo</title>
    
    <!-- Memuat Font Inter dari Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../style.css">

    <!-- Memuat Ionicons (Bundel Lengkap) -->
    <script src="https://unpkg.com/ionicons@5.5.2/dist/ionicons.js"></script>
</head>
<body>

    <div class="dashboard-container">
        
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header"><h1>Ethigo<span>.</span></h1></div>
            <nav class="sidebar-nav">
                <ul>
                    <li>
                        <a href="../Dashboard/index.php">
                            <ion-icon name="grid-outline"></ion-icon>
                            <span>Dasbor</span>
                        </a>
                    </li>
                    <li>
                        <a href="../Materi/index.php">
                            <ion-icon name="book-outline"></ion-icon>
                            <span>Materi</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="active"> <!-- Halaman ini adalah 'Pengguna' -->
                            <ion-icon name="people-outline"></ion-icon>
                            <span>Pengguna</span>
                        </a>
                    </li>
                    <li><a href="../Perpustakaan/index.php"><ion-icon name="library-outline"></ion-icon><span>Perpustakaan</span></a></li>
                    <li><a href="../Review/index.php"><ion-icon name="star-outline"></ion-icon><span>Review</span></a></li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                <nav class="sidebar-nav">
                    <ul>
                       <li><a href="../../user&session/login.php" id="logout-btn" class="logout-link"><ion-icon name="log-out-outline"></ion-icon><span>Logout</span></a></li>
                    </ul>
                </nav>
            </div>
        </aside>

        <!-- Main Content Area -->
        <div class="main-content">
            
            <!-- Header -->
            <header class="main-header">
                <div class="search-bar">
                    <ion-icon name="search-outline"></ion-icon>
                    <input type="text" placeholder="Cari pengguna...">
                </div>
                <div class="header-profile">
                    <!-- ... (Icon dan profile sama seperti sebelumnya) ... -->
                    <div class="profile-info">
                        <img src="https://placehold.co/40x40/E7F2EF/19183B?text=AK" alt="Foto Profil">
                        <div class="profile-text">
                            <div class="profile-name">Andika Krisna</div>
                            <div class="profile-role">Admin</div>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Content -->
            <main class="content-area">
                <!-- Header Konten: Judul -->
                <div class="content-header">
                    <h2 class="content-title">Manajemen Pengguna</h2>
                    <!-- Tombol 'Tambah Pengguna' bisa diletakkan di sini jika perlu -->
                </div>
                
                <!-- Tabel Data Pengguna (dari tabel 'akun_user') -->
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Pengguna</th> <!-- name, email, profile_photo -->
                                <th class="col-username">Username</th> <!-- username -->
                                <th class="col-school">Asal Sekolah</th> <!-- school_origin -->
                                <th>Peran</th> <!-- role -->
                                <th>Status</th> <!-- status -->
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $statusClass = $row['status'] === 'banned' ? 'status-banned' : 'status-active';
                                $statusText  = $row['status'];
                                $banBtnClass = $row['status'] === 'banned' ? 'btn-unban' : 'btn-ban';
                                $banBtnIcon  = $row['status'] === 'banned' ? 'refresh-outline' : 'ban-outline';
                                $banBtnTitle = $row['status'] === 'banned' ? 'Aktifkan' : 'Banned';
                                $photo = $row['profile_photo'] ?: 'https://placehold.co/40x40/E7F2EF/19183B?text=U';
                                echo "
                                <tr>
                                    <td>
                                        <div class='user-info'>
                                            <img src='{$photo}' alt='Foto Profil'>
                                            <div>
                                                <div class='user-name'>{$row['name']}</div>
                                                <div class='user-email'>{$row['email']}</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class='col-username'>{$row['username']}</td>
                                    <td class='col-school'>{$row['school_origin']}</td>
                                    <td>{$row['role']}</td>
                                    <td><span class='status-badge {$statusClass}'>{$statusText}</span></td>
                                    <td>
                                        <button class='btn-icon {$banBtnClass}' data-id='{$row['id']}' title='{$banBtnTitle}'><ion-icon name='{$banBtnIcon}'></ion-icon></button>
                                    </td>
                                </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='6'>Belum ada pengguna.</td></tr>";
                        }
                        ?>
                        </tbody>
                    </table>
                </div>

            </main>
        </div>
    </div>

    <!-- Modal untuk Konfirmasi Banned/Unban -->
    <div class="modal" id="banModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="banModalTitle">Konfirmasi Aksi</h3>
                <button class="modal-close" id="closeBanModalBtn"><ion-icon name="close-outline"></ion-icon></button>
            </div>
            <div class="modal-body">
                <p id="banModalText">Apakah Anda yakin ingin melanjutkan?</p>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" id="cancelBanBtn">Batal</button>
                <button class="btn btn-danger" id="confirmBanBtn">Ya, Lanjutkan</button>
            </div>
        </div>
    </div>

    <!-- JavaScript untuk Interaktivitas Modal Banned -->
    <script>
            const banModal = document.getElementById('banModal');
            const banModalTitle = document.getElementById('banModalTitle');
            const banModalText = document.getElementById('banModalText');
            const closeBanModalBtn = document.getElementById('closeBanModalBtn');
            const cancelBanBtn = document.getElementById('cancelBanBtn');
            const confirmBanBtn = document.getElementById('confirmBanBtn');

            let targetRow = null;

            // Fungsi tutup modal BAN
            function closeBanModal() {
                banModal.style.display = 'none';
            }

            // Event listener untuk tombol tutup modal (X dan Batal)
            closeBanModalBtn.addEventListener('click', closeBanModal);
            cancelBanBtn.addEventListener('click', closeBanModal);
            
            // Delegasi event untuk semua tombol .btn-ban dan .btn-unban
            document.querySelector('.data-table').addEventListener('click', (event) => {
                const button = event.target.closest('.btn-ban, .btn-unban');
                if (!button) return; // Keluar jika yang diklik bukan tombol ban/unban

                targetRow = button.closest('tr'); // Simpan baris target
                const userName = targetRow.querySelector('.user-name').textContent;
                const statusBadge = targetRow.querySelector('.status-badge');
                const isBanned = statusBadge.classList.contains('status-banned');

                if (isBanned) {
                    // Konfigurasi modal untuk UNBAN
                    banModalTitle.textContent = 'Aktifkan Pengguna';
                    banModalText.innerHTML = `Apakah Anda yakin ingin mengaktifkan kembali pengguna <strong>${userName}</strong>?`;
                    confirmBanBtn.textContent = 'Ya, Aktifkan';
                    confirmBanBtn.className = 'btn btn-primary'; // Tombol jadi hijau/primary
                } else {
                    // Konfigurasi modal untuk BAN
                    banModalTitle.textContent = 'Banned Pengguna';
                    banModalText.innerHTML = `Apakah Anda yakin ingin mem-banned pengguna <strong>${userName}</strong>?`;
                    confirmBanBtn.textContent = 'Ya, Banned';
                    confirmBanBtn.className = 'btn btn-danger'; // Tombol jadi merah
                }
                
                banModal.style.display = 'flex'; // Tampilkan modal
            });

            // Event listener untuk tombol konfirmasi di modal
            confirmBanBtn.addEventListener('click', () => {
                if (!targetRow) return;

                const userId = targetRow.querySelector('.btn-ban, .btn-unban').dataset.id;
                const isBanned = targetRow.querySelector('.status-badge').classList.contains('status-banned');

                // Tentukan status baru
                const newStatus = isBanned ? 'active' : 'banned';

                // Kirim AJAX ke backend
                fetch(`./crud_pengguna.php?action=toggleStatus&id=${userId}&status=${newStatus}`)
                    .then(res => res.text())
                    .then(response => {
                        if (response !== "success") {
                            alert("Gagal mengubah status!");
                        }

                        // Update UI
                        const statusBadge = targetRow.querySelector('.status-badge');
                        const banButton = targetRow.querySelector('.btn-ban, .btn-unban');

                        if (newStatus === 'active') {
                            statusBadge.textContent = 'active';
                            statusBadge.classList.remove('status-banned');
                            statusBadge.classList.add('status-active');

                            banButton.title = 'Banned';
                            banButton.classList.remove('btn-unban');
                            banButton.classList.add('btn-ban');
                            banButton.querySelector('ion-icon').setAttribute('name', 'ban-outline');
                        } else {
                            statusBadge.textContent = 'banned';
                            statusBadge.classList.remove('status-active');
                            statusBadge.classList.add('status-banned');

                            banButton.title = 'Aktifkan';
                            banButton.classList.remove('btn-ban');
                            banButton.classList.add('btn-unban');
                            banButton.querySelector('ion-icon').setAttribute('name', 'refresh-outline');
                        }

                        closeBanModal();
                    });
            });
            
            // Menutup modal jika klik di luar area modal-content
            window.addEventListener('click', (event) => {
                if (event.target === banModal) {
                    closeBanModal();
                }
            });
    </script>

</body>
</html>