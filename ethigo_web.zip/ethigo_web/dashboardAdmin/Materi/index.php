<?php
require '../../config.php';
include './crud_materi.php';

// ✅ Ambil data pakai prepared statement
$query = "SELECT id, judul, description, thumbnail_url FROM materi ORDER BY id DESC";
$stmt = $conn->prepare($query);
$stmt->execute();
$materi = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Materi - Ethigo</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../style.css">
    <script src="https://unpkg.com/ionicons@5.5.2/dist/ionicons.js"></script>
</head>

<body>
    <div class="dashboard-container">
        
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header"><h1>Ethigo<span>.</span></h1></div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="../Dashboard/index.php"><ion-icon name="grid-outline"></ion-icon><span>Dasbor</span></a></li>
                    <li><a href="#" class="active"><ion-icon name="book-outline"></ion-icon><span>Materi</span></a></li>
                    <li><a href="../Pengguna/index.php"><ion-icon name="people-outline"></ion-icon><span>Pengguna</span></a></li>
                    <li><a href="../Perpustakaan/index.php"><ion-icon name="library-outline"></ion-icon><span>Perpustakaan</span></a></li>
                    <li><a href="../Review/index.php"><ion-icon name="star-outline"></ion-icon><span>Review</span></a></li>
                </ul>
            </nav>
             <div class="sidebar-footer">
                <nav class="sidebar-nav">
                    <ul>
                       <li><a href="../../user&session/login.php" id="logout-btn" class="logout-link"><ion-icon name="log-out-outline"></ion-icon><span>Logout</span></a></li>
                    </ul>
                </nav>
            </div>
        </aside>

        <!-- Main Content -->
        <div class="main-content">
            
            <header class="main-header">
                <div class="search-bar">
                    <ion-icon name="search-outline"></ion-icon>
                    <input type="text" placeholder="Cari materi...">
                </div>
                <div class="header-profile">
                    <div class="header-icons">
                        <ion-icon name="notifications-outline"></ion-icon>
                        <ion-icon name="chatbubble-ellipses-outline"></ion-icon>
                    </div>
                    <div class="profile-info">
                        <img src="https://placehold.co/40x40/E7F2EF/19183B?text=AK" alt="Foto Profil">
                        <div class="profile-text">
                            <div class="profile-name">Andika Krisna</div>
                            <div class="profile-role">Admin</div>
                        </div>
                    </div>
                </div>
            </header>

            <main class="content-area">
                <div class="content-header">
                    <h2 class="content-title">Manajemen Materi</h2>
                    <button class="btn btn-primary" id="addMaterialBtn">
                        <ion-icon name="add-outline"></ion-icon>
                        Tambah Materi Baru
                    </button>
                </div>
                
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Thumbnail</th>
                                <th>Judul Materi</th>
                                <th>Deskripsi</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if ($materi && $materi->num_rows > 0): ?>
                            <?php while ($row = $materi->fetch_assoc()): ?>
                            <tr>
                                <td>
                                    <?php if (!empty($row['thumbnail_url'])): ?>
                                        <img src="<?= htmlspecialchars($row['thumbnail_url']) ?>" class="table-thumbnail" width="100">
                                    <?php else: ?>
                                        <img src="https://placehold.co/100x60/A1C2BD/19183B?text=No+Image" class="table-thumbnail" width="100">
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($row['judul']) ?></td>
                                <td><?= htmlspecialchars(substr($row['description'],0,50)) ?>...</td>
                                <td>
                                    <button class="btn-icon btn-edit" 
                                            data-id="<?= $row['id'] ?>"
                                            data-judul="<?= htmlspecialchars($row['judul']) ?>"
                                            data-deskripsi="<?= htmlspecialchars($row['description']) ?>"
                                            data-thumbnail="<?= htmlspecialchars($row['thumbnail_url']) ?>">
                                        <ion-icon name="pencil-outline"></ion-icon>
                                    </button>
                                    <form action="index.php" method="POST" style="display:inline;">
                                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                        <button class="btn-icon btn-delete" name="delete" onclick="return confirm('Hapus materi ini?')">
                                            <ion-icon name="trash-outline"></ion-icon>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="4" style="text-align:center;">Belum ada data materi</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

    <!-- Modal tetap di sini -->
    <div class="modal" id="materialModal">
        <form class="modal-content" method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" id="materialId">
            <div class="modal-header">
                <h3 class="modal-title" id="modalTitle">Tambah Materi Baru</h3>
                <button class="modal-close" id="closeModalBtn"><ion-icon name="close-outline"></ion-icon></button>
            </div>
            <div class="modal-body">
                <div id="materialForm">
                    <div class="form-group">
                        <label for="materialTitle">Judul Materi</label>
                        <input name="judul" type="text" id="materialTitle" class="form-control" placeholder="cth: Pengenalan JavaScript">
                    </div>
                    <div class="form-group">
                        <label>Thumbnail (JPG, PNG)</label>
                        <div class="thumbnail-uploader">
                            <img src="https://placehold.co/300x170/201F4E/708993?text=Pilih+Thumbnail" id="thumbnailPreview" alt="Preview">
                            <input name="thumbnail" type="file" id="thumbnailInput" accept="image/jpeg, image/png">
                            <label for="thumbnailInput" class="btn btn-secondary">
                                <ion-icon name="cloud-upload-outline"></ion-icon>
                                Pilih File
                            </label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="materialDescription">Deskripsi</label>
                        <textarea name="deskripsi" id="materialDescription" class="form-control" rows="5" placeholder="Tulis deskripsi singkat materi..."></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" id="cancelBtn">Batal</button>
                <button class="btn btn-primary" id="saveBtn" name="save" type="submit">Simpan</button>
            </div>
        </form>
    </div>

    <!-- JavaScript Modal -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const modal = document.getElementById('materialModal');
            const addMaterialBtn = document.getElementById('addMaterialBtn');
            const closeModalBtn = document.getElementById('closeModalBtn');
            const cancelBtn = document.getElementById('cancelBtn');
            const modalTitle = document.getElementById('modalTitle');
            const materialForm = document.getElementById('materialForm');
            const editButtons = document.querySelectorAll('.btn-edit');
            const saveBtn = document.getElementById('saveBtn');
            const materialId = document.getElementById('materialId');
            const thumbnailPreview = document.getElementById('thumbnailPreview');
            const thumbnailInput = document.getElementById('thumbnailInput');

            const openModal = () => modal.style.display = 'flex';
            const closeModal = () => {
                modal.style.display = 'none';
                materialForm.reset();
                thumbnailPreview.src = 'https://placehold.co/300x170/201F4E/708993?text=Pilih+Thumbnail';
                materialId.value = '';
                saveBtn.name = 'save'; // reset kembali ke mode tambah
            };

            // 🟢 Mode tambah baru
            addMaterialBtn.addEventListener('click', () => {
                modalTitle.textContent = 'Tambah Materi Baru';
                saveBtn.name = 'save';
                materialId.value = '';
                openModal();
            });

            // 🟣 Mode edit
            editButtons.forEach(button => {
                button.addEventListener('click', () => {
                    modalTitle.textContent = 'Edit Materi';
                    materialId.value = button.dataset.id;
                    document.getElementById('materialTitle').value = button.dataset.judul;
                    document.getElementById('materialDescription').value = button.dataset.deskripsi;
                    thumbnailPreview.src = button.dataset.thumbnail || 'https://placehold.co/300x170/201F4E/708993?text=Pilih+Thumbnail';
                    saveBtn.name = 'save'; // biarkan tetap 'save' karena PHP kamu sudah handle via ID
                    openModal();
                });
            });

            closeModalBtn.addEventListener('click', closeModal);
            cancelBtn.addEventListener('click', closeModal);

            window.addEventListener('click', (e) => {
                if (e.target === modal) closeModal();
            });

            thumbnailInput.addEventListener('change', (event) => {
                const file = event.target.files[0];
                if (file && (file.type === 'image/jpeg' || file.type === 'image/png')) {
                    const reader = new FileReader();
                    reader.onload = (e) => { thumbnailPreview.src = e.target.result; };
                    reader.readAsDataURL(file);
                } else {
                    alert('Harap pilih file gambar .jpg atau .png');
                    thumbnailInput.value = '';
                }
            });
        });

    </script>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
