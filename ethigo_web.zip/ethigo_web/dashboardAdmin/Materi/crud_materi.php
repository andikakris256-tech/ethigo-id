<?php
include '../../config.php'; 
session_start();

// ✅ CREATE & UPDATE
if (isset($_POST['save'])) {
    $id         = $_POST['id'] ?? null;
    $judul      = trim($_POST['judul']);
    $deskripsi  = trim($_POST['deskripsi']);
    $slug       = strtolower(str_replace(' ', '-', $judul));
    $created_by = $_SESSION['user_id'] ?? 1; // fallback jika belum login

    // --- Upload Thumbnail ---
    $thumb_url = '';
    if (!empty($_FILES['thumbnail']['name'])) {
        $file_name = time() . '_' . basename($_FILES['thumbnail']['name']);
        $target_path = 'upload/' . $file_name;
        if (move_uploaded_file($_FILES['thumbnail']['tmp_name'], $target_path)) {
            $thumb_url = $target_path;
        }
    }

    // --- Jika Update ---
    if (!empty($id)) {
        if ($thumb_url) {
            $query = "UPDATE materi SET judul=?, slug=?, description=?, thumbnail_url=? WHERE id=?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ssssi", $judul, $slug, $deskripsi, $thumb_url, $id);
        } else {
            $query = "UPDATE materi SET judul=?, slug=?, description=? WHERE id=?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("sssi", $judul, $slug, $deskripsi, $id);
        }
        $stmt->execute();
        $stmt->close();
    } 
    // --- Jika Tambah Baru ---
    else {
        $query = "INSERT INTO materi (slug, judul, description, thumbnail_url, created_by) 
                  VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssssi", $slug, $judul, $deskripsi, $thumb_url, $created_by);
        $stmt->execute();
        $stmt->close();
    }

    header('Location: index.php');
    exit;
}

// ✅ DELETE
if (isset($_POST['delete'])) {
    $id = $_POST['id'];
    $query = "DELETE FROM materi WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();

    header('Location: index.php');
    exit;
}

// ✅ READ DATA
$query = "SELECT id, judul, description, thumbnail_url FROM materi ORDER BY id DESC";
$stmt = $conn->prepare($query);
$stmt->execute();
$materi = $stmt->get_result();
?>