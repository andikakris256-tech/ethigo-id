<?php
include '../../config.php';
session_start();

// =============== CREATE / UPDATE ===============
if (isset($_POST['save'])) {

    $id    = $_POST['id'] ?? '';
    $judul = trim($_POST['judul']);
    $link  = trim($_POST['link']);
    $old   = $_POST['old_cover'] ?? '';

    // Upload Cover
    $cover_url = $old;
    if (!empty($_FILES['cover']['name'])) {
        $file_name = time() . '_' . basename($_FILES['cover']['name']);
        $target_path = 'upload/' . $file_name;

        if (move_uploaded_file($_FILES['cover']['tmp_name'], $target_path)) {
            $cover_url = $target_path;
        }
    }

    // UPDATE
    if (!empty($id)) {
        $query = "UPDATE perpustakaan SET judul=?, link=?, cover_url=? WHERE id=?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssi", $judul, $link, $cover_url, $id);
        $stmt->execute();
        $stmt->close();
    } 
    
    // CREATE
    else {
        $query = "INSERT INTO perpustakaan (judul, link, cover_url) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sss", $judul, $link, $cover_url);
        $stmt->execute();
        $stmt->close();
    }

    header("Location: index.php");
    exit;
}


// =============== DELETE ===============
if (isset($_POST['delete'])) {
    $id = $_POST['id'];

    $query = "DELETE FROM perpustakaan WHERE id=?";
    $stmt  = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();

    header("Location: index.php");
    exit;
}


// =============== READ DATA ===============
$query = "SELECT * FROM perpustakaan ORDER BY id DESC";
$stmt = $conn->prepare($query);
$stmt->execute();
$data = $stmt->get_result();
?>
