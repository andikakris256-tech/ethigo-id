<?php

include "./crud_perpustakaan.php";

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Perpustakaan - Ethigo</title>
    
    <!-- Memuat Font Inter dari Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../style.css">
    <!-- Memuat Ionicons (Bundel Lengkap) -->
    <script src="https://unpkg.com/ionicons@5.5.2/dist/ionicons.js"></script>
    
</head>
<body>

    <div class="dashboard-container">
        
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header"><h1>Ethigo<span>.</span></h1></div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="../Dashboard/index.php"><ion-icon name="grid-outline"></ion-icon><span>Dasbor</span></a></li>
                    <li><a href="../Materi/index.php"><ion-icon name="book-outline"></ion-icon><span>Materi</span></a></li>
                    <li><a href="../Pengguna/index.php"><ion-icon name="people-outline"></ion-icon><span>Pengguna</span></a></li>
                    <li><a href="" class="active"><ion-icon name="library-outline"></ion-icon><span>Perpustakaan</span></a></li>
                    <li><a href="../Review/index.php"><ion-icon name="star-outline"></ion-icon><span>Review</span></a></li>
                </ul>
            </nav>
             <div class="sidebar-footer">
                <nav class="sidebar-nav">
                    <ul>
                       <li><a href="../../user&session/login.php" id="logout-btn" class="logout-link"><ion-icon name="log-out-outline"></ion-icon><span>Logout</span></a></li>
                    </ul>
                </nav>
            </div>
        </aside>

        <!-- Main Content Area -->
        <div class="main-content">
            
            <!-- Header -->
            <header class="main-header">
                <div class="search-bar">
                    <ion-icon name="search-outline"></ion-icon>
                    <input type="text" placeholder="Cari di perpustakaan...">
                </div>
                <div class="header-profile">
                    <!-- ... (Icon dan profile sama seperti sebelumnya) ... -->
                    <div class="profile-info">
                        <img src="https://placehold.co/40x40/E7F2EF/19183B?text=AK" alt="Foto Profil">
                        <div class="profile-info-text">
                            <div class="profile-name">Andika Krisna</div>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Content -->
            <main class="content-area">
                <!-- Header Konten: Judul + Tombol Tambah -->
                <div class="content-header">
                    <h2 class="content-title">Manajemen Perpustakaan</h2>
                    <button class="btn btn-primary" id="addItemBtn">
                        <ion-icon name="add-outline"></ion-icon>
                        Tambah Item Baru
                    </button>
                </div>
                
                <!-- Tabel Data Perpustakaan (dari tabel 'perpustakaan') -->
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Cover</th> <!-- dari 'cover_url' (BARU) -->
                                <th>Judul</th> <!-- dari 'judul' -->
                                <th class="col-link">Link Eksternal</th> <!-- dari 'link' -->
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = $data->fetch_assoc()): ?>
                                <tr data-id="<?= $row['id'] ?>">
                                    <td><img src="<?= $row['cover_url'] ?>" class="cover-image"></td>
                                    <td class="title"><?= $row['judul'] ?></td>
                                    <td><a href="<?= $row['link'] ?>" class="item-link" target="_blank"><?= $row['link'] ?></a></td>

                                    <td>
                                        <button class="btn-icon btn-edit"><ion-icon name="pencil-outline"></ion-icon></button>
                                        <button class="btn-icon btn-delete"><ion-icon name="trash-outline"></ion-icon></button>
                                    </td>
                                </tr>
                            <?php endwhile ?>
                        </tbody>
                    </table>
                </div>

            </main>
        </div>
    </div>

    <!-- Modal untuk Tambah / Edit Item (Hidden by default) -->
    <div class="modal" id="itemModal">
            <form class="modal-content" id="itemForm" method="POST" enctype="multipart/form-data">
            <!-- Modal Header -->
            <div class="modal-header">
                <h3 class="modal-title" id="modalTitle">Tambah Item Baru</h3>
                <button class="modal-close" id="closeModalBtn"><ion-icon name="close-outline"></ion-icon></button>
            </div>
            
            <!-- Modal Body (Formulir) -->
            <div class="modal-body">
                    <input type="hidden" name="id" id="itemId">
                    <input type="hidden" name="old_cover" id="oldCover">

                    <div class="form-group">
                        <label for="itemTitle">Judul Item</label>
                        <input type="text" name="judul" id="itemTitle" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="itemLink">Link Eksternal (URL)</label>
                        <input type="url" name="link" id="itemLink" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label>Cover (JPG, PNG)</label>
                        <div class="cover-uploader">
                            <img src="https://placehold.co/300x170/201F4E/708993?text=Pilih+Cover" id="coverPreview">
                            <input type="file" name="cover" id="coverInput" accept="image/png, image/jpeg">
                            <label for="coverInput" class="btn btn-secondary">
                                <ion-icon name="cloud-upload-outline"></ion-icon>
                                Pilih File
                            </label>
                        </div>
                    </div>
            </div>

            <!-- Modal Footer -->
            <div class="modal-footer">
                <button class="btn btn-secondary" id="cancelBtn">Batal</button>
                <button class="btn btn-primary" id="saveBtn" type="submit" name="save">Simpan</button>
            </div>
        </form>
    </div>
    
    <!-- Modal untuk Konfirmasi Hapus -->
    <div class="modal" id="confirmModal">
        <div class="modal-content modal-confirm">
            <div class="modal-header">
                <h3 class="modal-title">Konfirmasi Hapus</h3>
                <button class="modal-close" id="closeConfirmModalBtn">
                    <ion-icon name="close-outline"></ion-icon>
                </button>
            </div>

            <div class="modal-body modal-body-confirm">
                <p id="confirmModalText">Apakah Anda yakin ingin menghapus item ini?</p>
            </div>

            <div class="modal-footer">

                <button class="btn btn-secondary" id="cancelConfirmBtn">Batal</button>

                <!-- Form delete yang dinamis -->
                <form id="deleteForm" action="./crud_perpustakaan.php" method="POST">
                    <input type="hidden" name="delete" value="1">
                    <input type="hidden" name="id" id="deleteItemId">
                    <button type="submit" class="btn-danger">Ya, Hapus</button>
                </form>

            </div>
        </div>
    </div>

    <!-- JavaScript untuk Interaktivitas -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            
            // --- Modal 1: Tambah/Edit Item ---
            const itemModal = document.getElementById('itemModal');
            const addItemBtn = document.getElementById('addItemBtn');
            const closeModalBtn = document.getElementById('closeModalBtn');
            const cancelBtn = document.getElementById('cancelBtn');
            const modalTitle = document.getElementById('modalTitle');
            const itemForm = document.getElementById('itemForm');
            const coverInput = document.getElementById('coverInput');
            const coverPreview = document.getElementById('coverPreview');

            // --- Modal 2: Konfirmasi Hapus ---
            const confirmModal = document.getElementById('confirmModal');
            const closeConfirmModalBtn = document.getElementById('closeConfirmModalBtn');
            const cancelConfirmBtn = document.getElementById('cancelConfirmBtn');
            const confirmBtn = document.getElementById('confirmBtn');
            const confirmModalText = document.getElementById('confirmModalText');
            
            let targetRow = null; // Menyimpan baris (tr) yang sedang diedit/dihapus

            // Fungsi untuk menampilkan modal item
            const openItemModal = () => {
                itemModal.style.display = 'flex';
            };

            // Fungsi untuk menutup modal item
            const closeItemModal = () => {
                itemModal.style.display = 'none';
                itemForm.reset(); 
                coverPreview.src = 'https://placehold.co/300x170/201F4E/708993?text=Pilih+Cover';
            };
            
            // Fungsi untuk menutup modal konfirmasi
            const closeConfirmModal = () => {
                confirmModal.style.display = 'none';
                targetRow = null;
            };

            // Event listener untuk tombol "Tambah Item"
            addItemBtn.addEventListener('click', () => {
                targetRow = null; // Pastikan tidak ada target row
                modalTitle.textContent = 'Tambah Item Baru';
                openItemModal();
            });

            // Delegasi event untuk tombol di tabel
            document.querySelector('.data-table').addEventListener('click', (event) => {
                const button = event.target.closest('button');
                if (!button) return; // Keluar jika bukan button

                targetRow = button.closest('tr'); // Simpan baris target
                
                // --- Logika Tombol Edit ---
                if (button.classList.contains('btn-edit')) {
                    const id = targetRow.dataset.id;
                    const title = targetRow.querySelector('.title').textContent;
                    const link = targetRow.querySelector('.item-link').href;
                    const imgSrc = targetRow.querySelector('.cover-image').src;

                    document.getElementById("itemId").value = id;
                    document.getElementById("oldCover").value = imgSrc;
                    document.getElementById("itemTitle").value = title;
                    document.getElementById("itemLink").value = link;

                    coverPreview.src = imgSrc;

                    modalTitle.textContent = "Edit Item";
                    itemModal.style.display = 'flex';
                }

                // --- Logika Tombol Hapus ---
                if (button.classList.contains('btn-delete')) {
                    const id = targetRow.dataset.id;
                    const title = targetRow.querySelector('.title').textContent;

                    // tampilkan judul di modal
                    confirmModalText.innerHTML = `Apakah Anda yakin ingin menghapus <strong>${title}</strong>?`;

                    // masukkan ID ke form delete di modal
                    document.getElementById('deleteItemId').value = id;

                    confirmModal.style.display = 'flex';
                }
            });

            // Event listener untuk tombol tutup modal (X dan Batal)
            closeModalBtn.addEventListener('click', closeItemModal);
            cancelBtn.addEventListener('click', closeItemModal);
            closeConfirmModalBtn.addEventListener('click', closeConfirmModal);
            cancelConfirmBtn.addEventListener('click', closeConfirmModal);
            
            // Menutup modal jika klik di luar
            window.addEventListener('click', (event) => {
                if (event.target === itemModal) closeItemModal();
                if (event.target === confirmModal) closeConfirmModal();
            });

            // --- Fitur 1 & 2: Pratinjau Cover ---
            coverInput.addEventListener('change', (event) => {
                const file = event.target.files[0];
                if (file && (file.type === 'image/jpeg' || file.type === 'image/png')) {
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        coverPreview.src = e.target.result;
                    };
                    reader.readAsDataURL(file);
                } else {
                    console.warn('Harap pilih file gambar .jpg atau .png');
                    coverInput.value = '';
                }
            });
        });
    </script>

</body>
</html>