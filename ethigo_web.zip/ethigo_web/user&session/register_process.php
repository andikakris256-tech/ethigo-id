<?php
// register_process.php
session_start();
require '../config.php'; // harus berisi $conn (mysqli)
require 'functions.php';

if($_SERVER['REQUEST_METHOD'] !== 'POST'){
    header('Location: register.php'); exit;
}

// ambil & bersihkan
$name = clean($_POST['name'] ?? '');
$username = clean($_POST['username'] ?? '');
$email = filter_var($_POST['email'] ?? '', FILTER_VALIDATE_EMAIL) ? clean($_POST['email']) : '';
$password = $_POST['password'] ?? '';
$school_origin = clean($_POST['school_origin'] ?? '');
$birth_date = clean($_POST['birth_date'] ?? '');
$gender = clean($_POST['gender'] ?? '');
$occupation = clean($_POST['occupation'] ?? '');
$phone_number = clean($_POST['phone_number'] ?? '');

// Validasi server-side (sama rules)
if(!$name || !is_valid_name($name)){
    $_SESSION['flash_error'] = 'invalid character';
    header('Location: register.php'); exit;
}
if(!$username || !is_valid_username($username)){
    $_SESSION['flash_error'] = 'invalid username';
    header('Location: register.php'); exit;
}
if(!$email){
    $_SESSION['flash_error'] = 'Email invalid';
    header('Location: register.php'); exit;
}
if(!is_valid_password($password)){
    $_SESSION['flash_error'] = 'invalid password';
    header('Location: register.php'); exit;
}
if(!$school_origin){
    $_SESSION['flash_error'] = 'Asal sekolah wajib diisi';
    header('Location: register.php'); exit;
}
if(!$birth_date){
    $_SESSION['flash_error'] = 'Tanggal lahir wajib diisi';
    header('Location: register.php'); exit;
}
if(!in_array($gender, ['Perempuan','Laki-laki'])){
    $_SESSION['flash_error'] = 'Jenis kelamin invalid';
    header('Location: register.php'); exit;
}
if(!$occupation || !is_valid_occupation($occupation)){
    $_SESSION['flash_error'] = 'invalid occupation';
    header('Location: register.php'); exit;
}
if(!$phone_number || !is_valid_phone($phone_number)){
    $_SESSION['flash_error'] = 'phone number invalid';
    header('Location: register.php'); exit;
}

// Cek unik username/email
$stmt = $conn->prepare("SELECT id FROM akun_user WHERE username = ? OR email = ? LIMIT 1");
$stmt->bind_param('ss', $username, $email);
$stmt->execute();
$stmt->store_result();
if($stmt->num_rows > 0){
    $_SESSION['flash_error'] = 'Username atau email sudah terdaftar';
    $stmt->close();
    header('Location: register.php'); exit;
}
$stmt->close();

// Hash password & simpan
$hash = password_hash($password, PASSWORD_DEFAULT);
$insert = $conn->prepare("INSERT INTO akun_user (name, username, email, password_hash, school_origin, birth_date, gender, occupation, phone_number, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
$insert->bind_param('sssssssss', $name, $username, $email, $hash, $school_origin, $birth_date, $gender, $occupation, $phone_number);
if($insert->execute()){
    $_SESSION['flash_success'] = 'Pendaftaran berhasil. Silakan login.';
    $insert->close();
    header('Location: login.php'); exit;
} else {
    $_SESSION['flash_error'] = 'Terjadi error, coba lagi.';
    $insert->close();
    header('Location: register.php'); exit;
}
