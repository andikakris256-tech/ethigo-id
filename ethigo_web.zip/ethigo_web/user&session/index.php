<?php
session_start();
require 'functions.php';
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Login - EthiGo</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="../style.css">
</head>
<body>
<div class="container">
  <div class="left card">
    <div class="brand">EthiGo</div>
    <div class="h1">Masuk</div>

    <?php if(!empty($_SESSION['flash_error'])): ?>
      <div class="error"><?php echo $_SESSION['flash_error']; unset($_SESSION['flash_error']); ?></div>
    <?php endif; ?>

    <form action="login_process.php" method="post">
      <label>Username atau Email</label>
      <input type="text" name="identity" required>

      <label>Password</label>
      <input type="password" name="password" required>

      <button class="btn" type="submit">Login</button>
    </form>

    <div class="footer-note">Belum punya akun? <a href="register.php">Register</a></div>
  </div>

  <div class="right">
    <div class="card">
      <div class="header-small">Keamanan</div>
      <p class="small-note">Password disimpan dengan hashing. Sesi diregenerasi saat login.</p>
    </div>
  </div>
</div>
</body>
</html>
