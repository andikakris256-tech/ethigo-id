<?php
// inc/functions.php
function clean($val){
    return trim(htmlspecialchars($val, ENT_QUOTES, 'UTF-8'));
}

function is_valid_name($name){
    // huruf dan spasi saja
    return preg_match('/^[A-Za-z\s]+$/u', $name);
}

function is_valid_username($username){
    // tidak boleh ada spasi
    return (strpos($username, ' ') === false) && strlen($username) > 0;
}

function is_valid_password($pwd){
    // minimal 8 karakter, setidaknya 1 huruf & 1 angka
    if(strlen($pwd) < 8) return false;
    return preg_match('/[A-Za-z]/', $pwd) && preg_match('/[0-9]/', $pwd);
}

function is_valid_phone($phone){
    return preg_match('/^[0-9]+$/', $phone);
}

function is_valid_occupation($occ){
    // huruf dan spasi saja
    return preg_match('/^[A-Za-z\s]+$/u', $occ);
}
