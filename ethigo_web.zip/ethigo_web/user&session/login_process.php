<?php
// login_process.php
session_start();
include '../config.php';
require 'functions.php';

if($_SERVER['REQUEST_METHOD'] !== 'POST'){
    header('Location: login.php'); exit;
}

$identity = clean($_POST['identity'] ?? '');
$password = $_POST['password'] ?? '';

if(empty($identity) || empty($password)){
    $_SESSION['flash_error'] = 'Masukkan username/email dan password.';
    header('Location: login.php'); exit;
}

// cari berdasarkan username atau email
$stmt = $conn->prepare("SELECT id, username, email, password_hash, role, status FROM akun_user WHERE username = ? OR email = ? LIMIT 1");
$stmt->bind_param('ss', $identity, $identity);
$stmt->execute();
$res = $stmt->get_result();
$user = $res->fetch_assoc();
$stmt->close();

if(!$user){
    $_SESSION['flash_error'] = 'User tidak ditemukan.';
    header('Location: login.php'); exit;
}

if($user['status'] !== 'active'){
    $_SESSION['flash_error'] = 'Akun tidak aktif.';
    header('Location: login.php'); exit;
}

if(password_verify($password, $user['password_hash'])){
    // Login sukses: setup session
    session_regenerate_id(true);
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['photo'] = $user['profile_photo'];
    $_SESSION['logged_in'] = time();
    
    // update last_login
    $upd = $conn->prepare("UPDATE akun_user SET last_login = NOW() WHERE id = ?");
    $upd->bind_param('i', $user['id']);
    $upd->execute();
    $upd->close();

    if ($_SESSION['role']=='admin'){
        header('Location: ../dashboardAdmin/Dashboard/index.php'); exit;

    } else {
        header('Location: ../user/dashboard/index.php'); exit;

    }

} else {
    $_SESSION['flash_error'] = 'Password salah.';
    header('Location: login.php'); exit;
}
