<?php
// register.php
session_start();
require 'functions.php';
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Register - EthiGo</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
  <div class="left card">
    <div class="brand">EthiGo</div>
    <div class="h1">Buat Akun Baru</div>

    <?php if(!empty($_SESSION['flash_error'])): ?>
      <div class="error"><?php echo $_SESSION['flash_error']; unset($_SESSION['flash_error']); ?></div>
    <?php endif; ?>
    <?php if(!empty($_SESSION['flash_success'])): ?>
      <div class="success"><?php echo $_SESSION['flash_success']; unset($_SESSION['flash_success']); ?></div>
    <?php endif; ?>

    <form id="registerForm" action="register_process.php" method="post" novalidate>
      <label>Nama lengkap</label>
      <input type="text" name="name" required>

      <label>Username</label>
      <input type="text" name="username" required>

      <label>Email</label>
      <input type="email" name="email" required>

      <label>Password</label>
      <input type="password" name="password" required>
      <div class="small-note">Minimal 8 karakter, harus mengandung huruf & angka.</div>

      <label>Asal Sekolah / Perguruan Tinggi</label>
      <input type="text" name="school_origin" required>

      <label>Tanggal Lahir</label>
      <input type="date" name="birth_date" required>

      <label>Jenis Kelamin</label>
      <select name="gender" required>
        <option value="">-- Pilih --</option>
        <option value="Perempuan">Perempuan</option>
        <option value="Laki-laki">Laki-laki</option>
      </select>

      <label>Pekerjaan</label>
      <select name="occupation" required>
        <option value="">-- Pilih --</option>
        <option value="pelajar">pelajar</option>
        <option value="mahasiswa">mahasiswa</option>
        <option value="guru">guru</option>
        <option value="dosen">dosen</option>
        <option value="pekerja">pekerja</option>
      </select>

      <label>Phone number</label>
      <input type="tel" name="phone_number" required>

      <button class="btn" type="submit">Register</button>
    </form>
    <div class="footer-note">Sudah punya akun? <a href="login.php">Login</a></div>
  </div>

  <div class="right">
    <div class="card">
      <div class="header-small">Kenapa harus mendaftar?</div>
      <p class="small-note">Akses konten eksklusif. Pastikan semua kolom diisi dengan benar. Validasi dilakukan di sisi client & server.</p>
    </div>
  </div>
</div>

<script>
// Client-side validation
document.getElementById('registerForm').addEventListener('submit', function(e){
  let f = e.target;
  let name = f.name.value.trim();
  let username = f.username.value.trim();
  let password = f.password.value;
  let phone = f.phone_number.value.trim();
  let occupation = f.occupation.value.trim();

  if(!/^[A-Za-z\s]+$/.test(name)){
    alert('invalid character');
    e.preventDefault(); return false;
  }
  if(/\s/.test(username) || username.length===0){
    alert('invalid username');
    e.preventDefault(); return false;
  }
  if(password.length < 8 || !(/[A-Za-z]/.test(password) && /[0-9]/.test(password))){
    alert('invalid password');
    e.preventDefault(); return false;
  }
  if(!/^[0-9]+$/.test(phone)){
    alert('phone number invalid');
    e.preventDefault(); return false;
  }
  if(occupation.length===0){
    alert('invalid occupation');
    e.preventDefault(); return false;
  }
});
</script>
</body>
</html>
