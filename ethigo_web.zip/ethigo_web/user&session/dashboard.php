<?php
session_start();
if(empty($_SESSION['user_id'])){
    header('Location: login.php'); exit;
}
require '../config.php';

// ambil data user
$stmt = $conn->prepare("SELECT id, name, username, email, school_origin, birth_date, gender, occupation, phone_number FROM akun_user WHERE id = ? LIMIT 1");
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$res = $stmt->get_result();
$user = $res->fetch_assoc();
$stmt->close();
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Dashboard - EthiGo</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
  <div class="left card">
    <div class="brand">EthiGo</div>
    <div class="h1">Selamat datang, <?php echo htmlspecialchars($user['name']); ?></div>
    <p class="small-note">Username: <?php echo htmlspecialchars($user['username']); ?></p>
    <p class="small-note">Email: <?php echo htmlspecialchars($user['email']); ?></p>
    <p class="small-note">Asal: <?php echo htmlspecialchars($user['school_origin']); ?></p>
    <p class="small-note">Phone: <?php echo htmlspecialchars($user['phone_number']); ?></p>

    <a class="btn" href="logout.php">Logout</a>
  </div>

  <div class="right">
    <div class="card">
      <div class="header-small">Akun</div>
      <p class="small-note">Di sini kamu bisa menambahkan fitur edit profile, upload foto, ganti password, dll.</p>
    </div>
  </div>
</div>
</body>
</html>
